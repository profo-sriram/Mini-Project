#!/usr/bin/env python3
"""Network Firewall System - command-line interface.

Examples::

    python main.py rules
    python main.py add-rule --action BLOCK --protocol TCP --dst-port 3389
    python main.py simulate                  # safe demo, no privileges needed
    sudo python main.py start --iface eth0   # live capture (monitor-only)
    python main.py status
    python main.py logs -n 30
    python main.py stop

NOTE: ``start`` evaluates and logs traffic; it does not drop packets. See
``python main.py export-iptables`` for OS-level enforcement.
"""

from __future__ import annotations

import argparse
import ipaddress
import json
import os
import signal
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

from firewall import __version__
from firewall.enforcer import generate_script
from firewall.logger import FirewallLogger, follow_log, tail_log
from firewall.models import PacketInfo
from firewall.packet_filter import FilterResult, PacketFilter
from firewall.packet_monitor import MonitorError, PacketMonitor
from firewall.rule_engine import (
    ACTIONS, RULE_PROTOCOLS, RuleError, RuleSet, normalize_port,
)
from firewall.runtime import (
    read_status, running_pid, stop_process, write_pid, write_status,
)
from firewall.settings import Settings, SettingsError
from firewall.simulator import generate_demo_packets
from firewall.threat_detector import ThreatDetector

BASE_DIR = Path(__file__).resolve().parent
DEFAULT_RULES = BASE_DIR / "config" / "rules.json"
DEFAULT_SETTINGS = BASE_DIR / "config" / "settings.json"
STATUS_INTERVAL = 2.0  # seconds between status-file updates


# --------------------------------------------------------------------------- #
# Output helpers
# --------------------------------------------------------------------------- #
def format_result(result: FilterResult) -> str:
    """One console line per packet, e.g. ``14:03:11 [BLOCKED] TCP a:1 -> b:23 (60 B) rule #2``."""
    packet, decision = result.packet, result.decision
    tag = "BLOCKED" if decision.is_blocked else "ALLOWED"
    rule = f"rule #{decision.rule.id}" if decision.rule else "default policy"
    return (
        f"{packet.time_str[11:]} [{tag}] {packet.protocol:<5} "
        f"{packet.src_endpoint} -> {packet.dst_endpoint} ({packet.size} B) {rule}"
    )


def print_table(headers: list[str], rows: list[list[str]]) -> None:
    widths = [max(len(h), *(len(r[i]) for r in rows)) if rows else len(h)
              for i, h in enumerate(headers)]
    line = "  ".join(h.ljust(w) for h, w in zip(headers, widths))
    print(line)
    print("  ".join("-" * w for w in widths))
    for row in rows:
        print("  ".join(cell.ljust(w) for cell, w in zip(row, widths)))


def load_rules(args: argparse.Namespace, create: bool = False) -> RuleSet:
    return RuleSet.load(args.rules, create_if_missing=create)


# --------------------------------------------------------------------------- #
# Rule administration commands
# --------------------------------------------------------------------------- #
def cmd_rules(args: argparse.Namespace) -> int:
    ruleset = load_rules(args)
    rules = ruleset.list_rules()
    if args.json:
        print(json.dumps([r.to_dict() for r in rules], indent=2))
        return 0
    print(f"Rules file     : {ruleset.path}")
    print(f"Default policy : {ruleset.default_policy}")
    print("Evaluation order: lowest priority number first; on a tie BLOCK beats ALLOW, "
          "then file order. First match wins.\n")
    if not rules:
        print("(no rules configured)")
        return 0
    print_table(
        ["ID", "PRI", "ACTION", "PROTO", "SRC IP", "SRC PORT", "DST IP", "DST PORT", "ON", "DESCRIPTION"],
        [[str(r.id), str(r.priority), r.action, r.protocol, r.src_ip, r.src_port,
          r.dst_ip, r.dst_port, "yes" if r.enabled else "no", r.description] for r in rules],
    )
    return 0


def cmd_add_rule(args: argparse.Namespace) -> int:
    ruleset = load_rules(args, create=True)
    rule = ruleset.add(
        action=args.action, protocol=args.protocol, src_ip=args.src_ip, dst_ip=args.dst_ip,
        src_port=args.src_port, dst_port=args.dst_port, priority=args.priority,
        description=args.description, enabled=False if args.disabled else None,
    )
    ruleset.save()
    print(f"Added rule #{rule.id}: {rule.describe()} (priority {rule.priority})")
    return 0


def cmd_update_rule(args: argparse.Namespace) -> int:
    ruleset = load_rules(args)
    enabled = True if args.enable else False if args.disable else None
    rule = ruleset.update(
        args.rule_id, action=args.action, protocol=args.protocol, src_ip=args.src_ip,
        dst_ip=args.dst_ip, src_port=args.src_port, dst_port=args.dst_port,
        priority=args.priority, description=args.description, enabled=enabled,
    )
    ruleset.save()
    print(f"Updated rule #{rule.id}: {rule.describe()} (priority {rule.priority}, "
          f"{'enabled' if rule.enabled else 'disabled'})")
    return 0


def cmd_remove_rule(args: argparse.Namespace) -> int:
    ruleset = load_rules(args)
    rule = ruleset.remove(args.rule_id)
    ruleset.save()
    print(f"Removed rule #{rule.id}: {rule.describe()}")
    return 0


def cmd_check(args: argparse.Namespace) -> int:
    """Dry-run: show which rule would decide for a hypothetical packet."""
    for label, value in (("--src-ip", args.src_ip), ("--dst-ip", args.dst_ip)):
        try:
            ipaddress.ip_address(value)
        except ValueError:
            print(f"Error: {label} {value!r} is not a valid IP address", file=sys.stderr)
            return 2
    ports: dict[str, int | None] = {}
    for label, value in (("src_port", args.src_port), ("dst_port", args.dst_port)):
        ports[label] = None if value is None else int(normalize_port(value, label))
    if args.protocol == "ICMP" and any(p is not None for p in ports.values()):
        print("Error: ICMP packets have no ports", file=sys.stderr)
        return 2
    packet = PacketInfo(args.src_ip, args.dst_ip, args.protocol, 0,
                        ports["src_port"], ports["dst_port"], tcp_flags="")
    decision = load_rules(args).evaluate(packet)
    print(f"{packet.protocol} {packet.src_endpoint} -> {packet.dst_endpoint}")
    print(f"Decision: {'BLOCKED' if decision.is_blocked else 'ALLOWED'}")
    print(f"Reason  : {decision.reason}")
    return 0


def cmd_export_iptables(args: argparse.Namespace) -> int:
    print(generate_script(load_rules(args)))
    return 0


# --------------------------------------------------------------------------- #
# Logs / status / stop
# --------------------------------------------------------------------------- #
def cmd_logs(args: argparse.Namespace) -> int:
    settings = Settings.load(args.settings, BASE_DIR)
    needle = {"all": None, "allowed": "| ALLOWED", "blocked": "| BLOCKED",
              "threats": "| THREAT"}[args.filter]
    if not settings.log_file.exists() and not args.follow:
        print(f"No log file yet at {settings.log_file}")
        return 0
    for line in tail_log(settings.log_file, args.lines, needle):
        print(line)
    if args.follow:
        try:
            for line in follow_log(settings.log_file, needle):
                print(line, flush=True)
        except KeyboardInterrupt:
            pass
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    settings = Settings.load(args.settings, BASE_DIR)
    pid = running_pid(settings.pid_file)
    status = read_status(settings.status_file)
    print(f"Firewall monitor: {'RUNNING (pid %d)' % pid if pid else 'STOPPED'}")
    if status:
        stats = status.get("stats", {})
        started = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(status.get("started_at", 0)))
        label = "Current run" if pid else "Last run"
        print(f"{label} started : {started}")
        print(f"Mode            : {status.get('mode', 'monitor-only')}")
        print(f"Interface       : {status.get('interface') or 'default'}")
        print(f"Packets seen    : {stats.get('total', 0)}")
        print(f"  allowed       : {stats.get('allowed', 0)}")
        print(f"  blocked       : {stats.get('blocked', 0)}")
        print(f"Threat alerts   : {stats.get('alerts', 0)}")
    try:
        ruleset = load_rules(args)
        print(f"Rules           : {len(ruleset)} (default policy {ruleset.default_policy})")
    except RuleError as exc:
        print(f"Rules           : ERROR - {exc}")
    print(f"Log file        : {settings.log_file}")
    return 0


def cmd_stop(args: argparse.Namespace) -> int:
    settings = Settings.load(args.settings, BASE_DIR)
    if running_pid(settings.pid_file) is None:
        print("Firewall monitor is not running.")
        return 0
    if stop_process(settings.pid_file):
        print("Firewall monitor stopped.")
        return 0
    print("Error: process did not stop within 5 seconds.", file=sys.stderr)
    return 1


# --------------------------------------------------------------------------- #
# start / simulate
# --------------------------------------------------------------------------- #
def build_filter(settings: Settings, ruleset: RuleSet) -> tuple[PacketFilter, FirewallLogger]:
    logger = FirewallLogger(settings.log_file, settings.log_max_bytes, settings.log_backup_count)
    detector = ThreatDetector(settings.threat) if settings.threat.enabled else None
    packet_filter = PacketFilter(ruleset, logger, detector, log_allowed=settings.log_allowed_packets)
    return packet_filter, logger


def print_banner(ruleset: RuleSet, settings: Settings) -> None:
    print(f"Network Firewall System v{__version__}")
    print("Mode  : MONITOR ONLY - packets are evaluated and logged, NOT dropped by this tool.")
    print("        For OS-level blocking see: python main.py export-iptables")
    print(f"Rules : {len(ruleset)} (default policy {ruleset.default_policy}) from {ruleset.path}")
    print(f"Log   : {settings.log_file}")


def print_result(result: FilterResult) -> None:
    print(format_result(result))
    for alert in result.alerts:
        print(f"   [!] THREAT {alert.kind} from {alert.src_ip}: {alert.message}")


def spawn_background(args: argparse.Namespace, settings: Settings) -> int:
    """Re-launch ``start`` as a detached child process (``start --detach``)."""
    cmd = [sys.executable, str(Path(__file__).resolve()), "--rules", str(args.rules),
           "--settings", str(args.settings), "start", "--quiet"]
    if args.iface:
        cmd += ["--iface", args.iface]
    if args.bpf:
        cmd += ["--bpf", args.bpf]
    settings.run_dir.mkdir(parents=True, exist_ok=True)
    kwargs: dict = {}
    if os.name == "nt":
        kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP | getattr(
            subprocess, "DETACHED_PROCESS", 0)
    else:
        kwargs["start_new_session"] = True
    with open(settings.console_file, "ab") as out:
        proc = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=out, stderr=out, **kwargs)
    for _ in range(20):
        time.sleep(0.25)
        if proc.poll() is not None:
            break
        if running_pid(settings.pid_file) == proc.pid:
            print(f"Firewall monitor started in background (pid {proc.pid}).")
            return 0
    print(f"Error: background start failed. See {settings.console_file} for details.",
          file=sys.stderr)
    return 1


def cmd_start(args: argparse.Namespace) -> int:
    settings = Settings.load(args.settings, BASE_DIR)
    ruleset = load_rules(args, create=True)
    live = args.pcap is None

    existing = running_pid(settings.pid_file) if live else None
    if existing:
        print(f"Error: firewall monitor already running (pid {existing}). "
              "Use 'python main.py stop' first.", file=sys.stderr)
        return 1
    if args.detach:
        if not live:
            print("Error: --detach cannot be combined with --pcap", file=sys.stderr)
            return 2
        return spawn_background(args, settings)
    if live and sys.platform != "win32" and hasattr(os, "geteuid") and os.geteuid() != 0:
        print("Warning: not running as root; packet capture will likely fail. "
              "Try: sudo python main.py start", file=sys.stderr)

    packet_filter, logger = build_filter(settings, ruleset)
    stop_event = threading.Event()
    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, lambda *_: stop_event.set())

    started_at = time.time()
    last_status = 0.0
    errors = 0

    def snapshot(running: bool) -> None:
        write_status(settings.status_file, {
            "running": running, "pid": os.getpid(), "started_at": started_at,
            "last_update": time.time(), "mode": "monitor-only", "interface": args.iface,
            "stats": packet_filter.stats.to_dict(),
        })

    def on_packet(packet: PacketInfo) -> None:
        nonlocal last_status, errors
        try:
            result = packet_filter.process(packet)
            if not args.quiet:
                print_result(result)
            if live and time.monotonic() - last_status >= STATUS_INTERVAL:
                last_status = time.monotonic()
                snapshot(True)
        except Exception as exc:  # keep capturing even if one packet misbehaves
            errors += 1
            if errors <= 5:
                logger.log_event(f"Error while processing packet: {exc!r}", 40)

    if live:
        write_pid(settings.pid_file)
    logger.log_event(f"Firewall started (rules={len(ruleset)}, "
                     f"{'pcap=' + args.pcap if args.pcap else 'live capture'})")
    if not args.quiet:
        print_banner(ruleset, settings)
        print("Press Ctrl+C to stop.\n")
    exit_code = 0
    try:
        PacketMonitor(on_packet, args.iface, args.bpf, args.pcap).run(stop_event)
    except MonitorError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        logger.log_event(f"Capture failed: {exc}", 40)
        exit_code = 1
    finally:
        stats = packet_filter.stats
        logger.log_event(f"Firewall stopped (packets={stats.total}, allowed={stats.allowed}, "
                         f"blocked={stats.blocked}, alerts={stats.alerts})")
        if live:
            snapshot(False)
            settings.pid_file.unlink(missing_ok=True)
        logger.close()
    if not args.quiet:
        print(f"\nStopped. packets={stats.total} allowed={stats.allowed} "
              f"blocked={stats.blocked} alerts={stats.alerts}")
    return exit_code


def cmd_simulate(args: argparse.Namespace) -> int:
    """Run synthetic traffic through the real rule engine, logger and detector."""
    settings = Settings.load(args.settings, BASE_DIR)
    ruleset = load_rules(args)
    log_path = settings.log_file
    if args.temp_log:
        log_path = Path(tempfile.mkdtemp(prefix="pyfw-sim-")) / "firewall.log"
        settings.log_file = log_path
    packet_filter, logger = build_filter(settings, ruleset)
    print_banner(ruleset, settings)
    print("Simulating demo traffic (no real packets are captured)...\n")
    try:
        for packet in generate_demo_packets():
            print_result(packet_filter.process(packet))
            if args.delay:
                time.sleep(args.delay)
    finally:
        logger.close()
    stats = packet_filter.stats
    print(f"\nDone. packets={stats.total} allowed={stats.allowed} "
          f"blocked={stats.blocked} alerts={stats.alerts}")
    print(f"See the log: {log_path}")
    return 0


# --------------------------------------------------------------------------- #
# Argument parsing
# --------------------------------------------------------------------------- #
def _rule_fields(parser: argparse.ArgumentParser, *, for_update: bool) -> None:
    group = parser.add_argument_group("rule fields")
    group.add_argument("--action", type=str.upper, choices=ACTIONS,
                       required=not for_update, help="ALLOW or BLOCK")
    group.add_argument("--protocol", type=str.upper, choices=RULE_PROTOCOLS,
                       default=None if for_update else "ANY", help="ANY, TCP, UDP or ICMP")
    group.add_argument("--src-ip", help="source IP or CIDR (default: any)")
    group.add_argument("--dst-ip", help="destination IP or CIDR (default: any)")
    group.add_argument("--src-port", help="source port or range, e.g. 1024-65535")
    group.add_argument("--dst-port", "--port", dest="dst_port",
                       help="destination port or range, e.g. 23 or 8000-8100")
    group.add_argument("--priority", type=int,
                       help="lower number = evaluated first (default: after existing rules)")
    group.add_argument("--description", help="free-text note")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="main.py", description="Network Firewall System (educational, lab use).")
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    parser.add_argument("--rules", type=Path, default=DEFAULT_RULES, help="path to rules.json")
    parser.add_argument("--settings", type=Path, default=DEFAULT_SETTINGS,
                        help="path to settings.json")
    sub = parser.add_subparsers(dest="command", required=True, metavar="COMMAND")

    p = sub.add_parser("start", help="start monitoring (foreground; Ctrl+C to stop)")
    p.add_argument("--iface", help="network interface to capture on (default: Scapy default)")
    p.add_argument("--bpf", help="optional BPF capture filter, e.g. 'tcp or udp or icmp'")
    p.add_argument("--pcap", help="analyse a .pcap file instead of live traffic")
    p.add_argument("--detach", "-d", action="store_true", help="run in the background")
    p.add_argument("--quiet", "-q", action="store_true", help="do not print each packet")
    p.set_defaults(func=cmd_start)

    sub.add_parser("stop", help="stop a running monitor").set_defaults(func=cmd_stop)
    sub.add_parser("status", help="show run state and counters").set_defaults(func=cmd_status)

    p = sub.add_parser("rules", help="list rules in evaluation order")
    p.add_argument("--json", action="store_true", help="output JSON")
    p.set_defaults(func=cmd_rules)

    p = sub.add_parser("add-rule", help="add a rule")
    _rule_fields(p, for_update=False)
    p.add_argument("--disabled", action="store_true", help="add the rule in disabled state")
    p.set_defaults(func=cmd_add_rule)

    p = sub.add_parser("update-rule", help="change fields of an existing rule")
    p.add_argument("rule_id", type=int, help="id of the rule")
    _rule_fields(p, for_update=True)
    state = p.add_mutually_exclusive_group()
    state.add_argument("--enable", action="store_true")
    state.add_argument("--disable", action="store_true")
    p.set_defaults(func=cmd_update_rule)

    p = sub.add_parser("remove-rule", help="remove a rule by id")
    p.add_argument("rule_id", type=int, help="id of the rule")
    p.set_defaults(func=cmd_remove_rule)

    p = sub.add_parser("logs", help="show the firewall log")
    p.add_argument("-n", "--lines", type=int, default=20, help="number of lines (default 20)")
    p.add_argument("-f", "--follow", action="store_true", help="keep printing new lines")
    p.add_argument("--filter", choices=["all", "allowed", "blocked", "threats"], default="all")
    p.set_defaults(func=cmd_logs)

    p = sub.add_parser("check", help="dry-run: which rule decides for a given packet?")
    p.add_argument("--protocol", type=str.upper, choices=["TCP", "UDP", "ICMP"], default="TCP")
    p.add_argument("--src-ip", default="10.0.0.2")
    p.add_argument("--dst-ip", default="10.0.0.5")
    p.add_argument("--src-port")
    p.add_argument("--dst-port", "--port", dest="dst_port")
    p.set_defaults(func=cmd_check)

    p = sub.add_parser("export-iptables",
                       help="print an iptables script for OS-level enforcement (not executed)")
    p.set_defaults(func=cmd_export_iptables)

    p = sub.add_parser("simulate", help="run a safe synthetic-traffic demo (no privileges)")
    p.add_argument("--delay", type=float, default=0.0, help="seconds between packets")
    p.add_argument("--temp-log", action="store_true",
                   help="write to a temporary log instead of logs/firewall.log")
    p.set_defaults(func=cmd_simulate)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return args.func(args)
    except (RuleError, SettingsError, MonitorError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        return 130
    except BrokenPipeError:  # e.g. output piped into `head`
        sys.stderr.close()
        return 0


if __name__ == "__main__":
    sys.exit(main())
