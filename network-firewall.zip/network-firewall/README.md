# Network Firewall System

A Python **rule-based network firewall and traffic monitor** for learning and for
controlled lab environments. It captures packets in real time with
[Scapy](https://scapy.net), evaluates them against configurable IP / port /
protocol rules, logs every decision, and raises warnings for basic suspicious
behaviour such as port scans.

> ## ⚠️ Monitoring vs. real blocking - please read
>
> Scapy sniffs a **copy** of packets that the operating system has *already
> delivered*. A user-space sniffer therefore **cannot drop traffic**.
>
> | Capability | How this project does it |
> |---|---|
> | **Packet monitoring & rule evaluation** | Built in. `start` decides ALLOW/BLOCK for each packet and logs it. **Nothing is dropped.** |
> | **Actual OS-level packet blocking** | Done by the OS firewall. `python main.py export-iptables` *generates* a reviewable `iptables`/`ip6tables` script from the same `rules.json`. The tool never executes it - an administrator reviews and applies it (as root, on a lab machine). |
>
> In this README "BLOCKED" means *"the rules say this packet should be blocked"*.
> Use only on networks and machines you own or are authorised to test.

---

## Features

- **Real-time capture** (Scapy) of IPv4/IPv6 TCP, UDP and ICMP: timestamp, source/destination IP, source/destination port, protocol, size.
- **Rule engine** - source/destination IP (single address or CIDR), source/destination port (single or range), protocol (`TCP`, `UDP`, `ICMP`, `ANY`), action `ALLOW`/`BLOCK`, priority, enable/disable.
- **JSON configuration** with strict validation (typos in field names are rejected, not ignored) and atomic saves.
- **CLI administration** - add, remove, update and list rules; a `check` dry-run to see which rule would decide.
- **Hot reload** - rules edited while the monitor runs are picked up automatically; a broken file keeps the previous rules active and logs an error.
- **Structured, rotating log** at `logs/firewall.log` (`key=value` fields, easy to grep).
- **Threat detection** - port scans, repeated connection attempts, repeated hits on blocked rules, excessive packet rate (thresholds in `config/settings.json`).
- **Safe demo mode** - `simulate` runs synthetic traffic through the real engine with no privileges and no Scapy needed.
- **Offline analysis** - replay a `.pcap` file with `start --pcap`.
- **OS enforcement bridge** - `export-iptables` (generate only).
- 60+ unit tests.

## Architecture

```text
 network ──► packet_monitor.py ──► PacketInfo ──► packet_filter.py ──► FilterResult
             (Scapy sniff,          (models.py)     │   │    │
              parse headers)                        │   │    └─► threat_detector.py ─► ThreatAlert
                                                    │   └──────► logger.py ─► logs/firewall.log
                                                    └──────────► rule_engine.py ◄── config/rules.json
 main.py (argparse CLI) ─► start / stop / status / rules / add-rule / ...
 enforcer.py ─► prints iptables script (no execution)
```

```text
network-firewall/
├── main.py                     # CLI entry point
├── config/
│   ├── rules.json              # firewall rules (sample included)
│   └── settings.json           # log + threat-detection settings
├── firewall/
│   ├── __init__.py
│   ├── models.py               # PacketInfo dataclass
│   ├── rule_engine.py          # Rule, RuleSet, validation, evaluation, persistence
│   ├── packet_monitor.py       # Scapy capture + header parsing
│   ├── packet_filter.py        # glue: rules + logging + threat detection + stats
│   ├── threat_detector.py      # sliding-window detections
│   ├── logger.py               # rotating structured log, tail/follow helpers
│   ├── enforcer.py             # iptables script generator (never executes)
│   ├── settings.py             # settings loader/validator
│   ├── runtime.py              # PID / status files for start-stop-status
│   └── simulator.py            # synthetic demo traffic
├── logs/                       # firewall.log is created here at runtime
├── tests/
│   ├── helpers.py
│   ├── test_rules.py
│   ├── test_filter.py
│   ├── test_threat_detector.py
│   └── test_logger.py
├── requirements.txt
├── README.md
└── .gitignore
```

## Technologies used

Python 3.11+ · Scapy (packet capture/parsing) · `argparse` (CLI) · `ipaddress` (IP/CIDR matching) · `logging` with `RotatingFileHandler` · `dataclasses` + type hints · `unittest`/`pytest`.

## Installation

```bash
git clone <your-repo-url> network-firewall && cd network-firewall
python3 -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

Platform notes for **live capture**:

- **Linux / macOS** - needs root (or `CAP_NET_RAW`). With a virtualenv use the venv's interpreter: `sudo .venv/bin/python main.py start`.
- **Windows** - install [Npcap](https://npcap.com) and run the terminal as Administrator.
- Everything else (rules, `check`, `simulate`, tests, `--pcap` analysis) needs **no privileges**.

## Running

### 1. Try it safely first (no privileges, no real traffic)

```bash
python main.py simulate --temp-log
```

### 2. Live monitoring (controlled lab only)

```bash
sudo .venv/bin/python main.py start --iface eth0        # foreground, Ctrl+C to stop
sudo .venv/bin/python main.py start --iface eth0 -d     # background
python main.py status
python main.py logs -n 30 --filter blocked              # or: allowed | threats | all; add -f to follow
python main.py stop
```

Useful `start` options: `--iface`, `--bpf "tcp or udp or icmp"` (capture filter), `--pcap file.pcap` (offline replay), `--quiet`.

### 3. Generate real OS-level rules (optional, lab machine only)

```bash
python main.py export-iptables > pyfw.sh      # review the file!
sudo sh pyfw.sh                               # creates chain PYFW; does NOT activate it
# then, only after review, activate by uncommenting/running:  iptables -I INPUT -j PYFW
```

The script is intentionally inert until you hook the chain in, includes rollback
commands, and warns that wrong rules can lock you out of a remote session.
Note that a chain in `INPUT` sees only inbound traffic.

## Configuring rules

Rules live in `config/rules.json`:

```json
{
  "version": 1,
  "default_policy": "ALLOW",
  "rules": [
    { "id": 2, "priority": 20, "action": "BLOCK", "protocol": "TCP",
      "src_ip": "any", "src_port": "any", "dst_ip": "any", "dst_port": "23",
      "enabled": true, "description": "Block Telnet" }
  ]
}
```

| Field | Values |
|---|---|
| `action` | `ALLOW` or `BLOCK` |
| `protocol` | `TCP`, `UDP`, `ICMP`, `ANY` (ICMP rules cannot have ports) |
| `src_ip` / `dst_ip` | `any`, an IP (`192.168.1.100`), or CIDR (`10.0.0.0/24`, `2001:db8::/32`) |
| `src_port` / `dst_port` | `any`, a port (`443`) or range (`8000-8100`) |
| `priority` | integer 1-65535; lower is evaluated first |
| `enabled` | `true` / `false` |
| `default_policy` | what happens when no rule matches (`ALLOW` or `BLOCK`) |

### Rule precedence (which rule wins?)

Rules are sorted and evaluated in this order; **the first enabled rule that matches decides**:

1. **Lower `priority` number first.**
2. On equal priority, **`BLOCK` before `ALLOW`** (deny overrides - safer if two rules overlap by mistake).
3. On equal priority and action, **earlier position in `rules.json`**.
4. If nothing matches, **`default_policy`** applies.

A rule matches only if *all* its specified criteria match. A port criterion never matches ICMP (no ports).
`python main.py rules` prints rules in this exact order. Example: to allow one host
through a broader block, give the ALLOW a smaller priority number than the BLOCK.

### Managing rules from the CLI

```bash
python main.py rules                                           # list (evaluation order)
python main.py add-rule --action BLOCK --protocol TCP --port 3389 --description "No RDP"
python main.py add-rule --action BLOCK --src-ip 203.0.113.0/24 --priority 5
python main.py update-rule 6 --dst-port 3380-3390 --disable    # also --enable
python main.py remove-rule 6
python main.py check --protocol TCP --src-ip 10.0.0.9 --dst-port 23   # dry run
```

`--port` is a shortcut for `--dst-port`. To block a host in **both directions** add two rules (one with `--src-ip`, one with `--dst-ip`). Invalid input (bad IP, port 70000, unknown protocol...) produces a clear error and changes nothing.

### Settings

`config/settings.json` holds the log path/rotation and detection thresholds (all values validated):

```json
"threat_detection": {
  "enabled": true, "window_seconds": 10,
  "port_scan_threshold": 15, "repeated_attempt_threshold": 10,
  "blocked_attempt_threshold": 5, "packet_rate_threshold": 200,
  "alert_cooldown_seconds": 30
}
```

## Threat detection

Per source IP, over a sliding window (`window_seconds`):

| Alert | Trigger |
|---|---|
| `PORT_SCAN` | ≥ `port_scan_threshold` distinct destination ports contacted |
| `REPEATED_CONNECTIONS` | ≥ `repeated_attempt_threshold` TCP SYNs to the same host:port |
| `BLOCKED_TRAFFIC` | ≥ `blocked_attempt_threshold` packets that matched a BLOCK rule (e.g. repeated hits on a blocked port) |
| `EXCESSIVE_TRAFFIC` | ≥ `packet_rate_threshold` packets |

The same alert for the same source is suppressed for `alert_cooldown_seconds` so the log is not flooded. Memory is bounded (per-source and global caps).

## Testing

```bash
python -m unittest discover -s tests -t . -v      # no extra packages needed
# or, if pytest is installed:
python -m pytest -v
```

Covered: IP / CIDR / IPv6 rules, port and range rules, protocol rules, ALLOW/BLOCK and default policy, multiple matching rules and precedence, invalid rules and malformed files, add/update/remove/save/load/hot-reload, threat detection (all four detections, cooldown, window expiry, bounded memory), logging (fields, levels, rotation, tail/follow), and the iptables generator. Tests use synthetic packets, so they need no privileges or network.

**Manual lab test** (two VMs on an isolated host-only network): run `start` on the target; from the other VM try `curl http://<target>`, `nc -vz <target> 23`, and a small `nmap -p 1-100 <target>`; watch the console and `python main.py logs --filter threats`.

## Example log output

```text
2026-10-01 07:37:21 | INFO    | ALLOWED | proto=TCP | src_ip=10.0.0.20 | src_port=50001 | dst_ip=10.0.0.5 | dst_port=80 | size=74 | rule=#3 | reason=Allowed by rule #3 (ALLOW TCP src=any:any dst=any:80)
2026-10-01 07:37:21 | INFO    | BLOCKED | proto=TCP | src_ip=10.0.0.30 | src_port=50100 | dst_ip=10.0.0.5 | dst_port=23 | size=60 | rule=#2 | reason=Blocked by rule #2 (BLOCK TCP src=any:any dst=any:23)
2026-10-01 07:37:22 | INFO    | ALLOWED | proto=ICMP | src_ip=10.0.0.22 | src_port=- | dst_ip=10.0.0.5 | dst_port=- | size=98 | rule=default-policy | reason=Allowed by default policy (ALLOW); no rule matched
2026-10-01 07:37:22 | WARNING | THREAT  | type=PORT_SCAN | src_ip=10.0.0.66 | details=possible port scan: 15 distinct destination ports in 10s
2026-10-01 07:37:23 | WARNING | THREAT  | type=REPEATED_CONNECTIONS | src_ip=10.0.0.77 | details=10 connection attempts (SYN) to 10.0.0.5:22 in 10s
2026-10-01 07:37:23 | WARNING | THREAT  | type=BLOCKED_TRAFFIC | src_ip=10.0.0.88 | details=5 packets hit BLOCK rules in 10s
```

Console output of `start` / `simulate`:

```text
07:37:21 [BLOCKED] TCP   10.0.0.30:50100 -> 10.0.0.5:23 (60 B) rule #2
   [!] THREAT PORT_SCAN from 10.0.0.66: possible port scan: 15 distinct destination ports in 10s
```

## Limitations

- **User-space monitoring cannot drop packets** (see the notice at the top). Enforcement requires the OS firewall.
- Detection is heuristic and threshold-based: it can produce false positives/negatives, and only sees traffic visible to the capture interface.
- Stateless matching: no TCP connection tracking, no payload (deep-packet) inspection, no reassembly or fragmentation handling; IPv6 extension headers are only partially understood.
- Source IPs can be spoofed; the detector trusts the packet headers.
- The `ICMP` category on IPv6 relies on the IPv6 "next header" being ICMPv6 directly.
- Rule changes made while running are picked up on a short polling interval (default 2 s).
- Single process, single-threaded evaluation - fine for lab traffic, not for line-rate production loads. `stop` on Windows terminates the process immediately (no graceful shutdown message).
- Scapy capture itself was not exercised in the automated tests (they use synthetic packets); verify it on your lab setup.

## Future enhancements

- Integrate directly with `nftables`/`iptables` (with confirmation + automatic rollback timer) or NFQUEUE for in-line verdicts.
- Stateful connection tracking and rate-limit rules; allow-lists for trusted scanners.
- GeoIP / threat-intelligence feeds; alert forwarding (email, syslog, Slack).
- Web dashboard and metrics (Prometheus), JSON log option.
- Rule import/export, rule groups, time-based rules, and a config schema (JSON Schema).
- Pcap capture of flagged traffic for forensics; packaging as a systemd service.

## Safety statement

Educational project for isolated lab use. It contains no malware, persistence, stealth, credential access or security-bypass techniques. It does not modify system firewall settings on its own.
