"""Network Firewall System - an educational, rule-based packet filter.

The package separates concerns into small modules:

* ``models``          - shared data classes (``PacketInfo``)
* ``rule_engine``     - rule model, validation, persistence and evaluation
* ``packet_monitor``  - live/offline packet capture (Scapy)
* ``packet_filter``   - ties rules, logging and threat detection together
* ``threat_detector`` - sliding-window suspicious activity detection
* ``logger``          - structured, rotating log file
* ``enforcer``        - *generates* OS firewall (iptables) commands; never runs them
"""

__version__ = "1.0.0"
