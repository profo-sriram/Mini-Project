"""Firewall rule model, validation, JSON persistence and evaluation.

Rule precedence (documented contract)
-------------------------------------
Rules are evaluated in this order and the **first matching, enabled rule wins**:

1. Lower ``priority`` number first (``10`` is evaluated before ``20``).
2. If priorities are equal, ``BLOCK`` is evaluated before ``ALLOW``
   ("deny overrides" - the safer choice when an admin makes an overlap by mistake).
3. If priority *and* action are equal, the rule that appears first in
   ``rules.json`` wins.

If no rule matches, the ``default_policy`` from the config file applies.
"""

from __future__ import annotations

import ipaddress
import json
import os
import tempfile
from dataclasses import dataclass, field, fields, replace
from functools import lru_cache
from pathlib import Path
from typing import Any

from .models import PacketInfo

ACTIONS = ("ALLOW", "BLOCK")
RULE_PROTOCOLS = ("ANY", "TCP", "UDP", "ICMP")
ANY = "any"
CONFIG_VERSION = 1
MAX_PRIORITY = 65535
MAX_DESCRIPTION_LEN = 200
_ACTION_RANK = {"BLOCK": 0, "ALLOW": 1}

_IPNetwork = ipaddress.IPv4Network | ipaddress.IPv6Network


# --------------------------------------------------------------------------- #
# Exceptions
# --------------------------------------------------------------------------- #
class RuleError(ValueError):
    """Base class for all rule-related errors."""


class RuleValidationError(RuleError):
    """A rule (or one of its fields) is invalid."""


class RuleNotFoundError(RuleError):
    """No rule exists with the requested id."""


class RuleFileError(RuleError):
    """The rules file is missing, unreadable or malformed."""


# --------------------------------------------------------------------------- #
# Field normalisation / validation
# --------------------------------------------------------------------------- #
def normalize_action(value: Any) -> str:
    """Return ``"ALLOW"`` or ``"BLOCK"`` or raise ``RuleValidationError``."""
    text = str(value).strip().upper() if value is not None else ""
    if text not in ACTIONS:
        raise RuleValidationError(f"Invalid action {value!r}; expected one of {ACTIONS}")
    return text


def normalize_protocol(value: Any) -> str:
    """Return one of ``ANY``, ``TCP``, ``UDP``, ``ICMP``."""
    if value is None:
        return "ANY"
    text = str(value).strip().upper()
    if text in ("", "*"):
        return "ANY"
    if text not in RULE_PROTOCOLS:
        raise RuleValidationError(f"Invalid protocol {value!r}; expected one of {RULE_PROTOCOLS}")
    return text


def normalize_ip(value: Any, field_name: str = "ip") -> str:
    """Normalise an IP/CIDR string. ``None``/``""``/``any``/``*`` mean "any"."""
    if value is None:
        return ANY
    text = str(value).strip().lower()
    if text in ("", "any", "*"):
        return ANY
    try:
        network = ipaddress.ip_network(text, strict=True)
    except ValueError as exc:
        raise RuleValidationError(f"Invalid {field_name} {value!r}: {exc}") from exc
    if "/" not in text:  # single host: keep it as a plain address
        return str(network.network_address)
    return str(network)


def _to_port_number(text: str, field_name: str) -> int:
    text = text.strip()
    if not (text.isascii() and text.isdigit()):
        raise RuleValidationError(f"Invalid {field_name} {text!r}: not a number")
    number = int(text)
    if not 1 <= number <= 65535:
        raise RuleValidationError(f"Invalid {field_name} {number}: must be 1-65535")
    return number


def normalize_port(value: Any, field_name: str = "port") -> str:
    """Normalise a port spec: ``any``, ``80`` or a range such as ``1000-2000``."""
    if value is None:
        return ANY
    if isinstance(value, bool):
        raise RuleValidationError(f"Invalid {field_name} {value!r}")
    if isinstance(value, int):
        low = high = _to_port_number(str(value), field_name)
    else:
        text = str(value).strip().lower()
        if text in ("", "any", "*"):
            return ANY
        if "-" in text:
            left, _, right = text.partition("-")
            low = _to_port_number(left, field_name)
            high = _to_port_number(right, field_name)
        else:
            low = high = _to_port_number(text, field_name)
    if low > high:
        raise RuleValidationError(f"Invalid {field_name} range: {low}-{high} (start > end)")
    return str(low) if low == high else f"{low}-{high}"


def _port_bounds(spec: str) -> tuple[int, int] | None:
    """Convert a normalised port spec to ``(low, high)``; ``None`` means any."""
    if spec == ANY:
        return None
    if "-" in spec:
        low, _, high = spec.partition("-")
        return int(low), int(high)
    return int(spec), int(spec)


@lru_cache(maxsize=4096)
def _parse_ip(text: str) -> ipaddress.IPv4Address | ipaddress.IPv6Address | None:
    try:
        return ipaddress.ip_address(text)
    except ValueError:
        return None


# --------------------------------------------------------------------------- #
# Rule
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class Rule:
    """A single firewall rule. Construction validates and normalises all fields."""

    action: str
    protocol: str = "ANY"
    src_ip: str = ANY
    dst_ip: str = ANY
    src_port: str = ANY
    dst_port: str = ANY
    priority: int = 100
    id: int = 0
    enabled: bool = True
    description: str = ""
    # Pre-compiled matchers (derived from the fields above; not serialised).
    _src_net: _IPNetwork | None = field(init=False, repr=False, compare=False, default=None)
    _dst_net: _IPNetwork | None = field(init=False, repr=False, compare=False, default=None)
    _src_ports: tuple[int, int] | None = field(init=False, repr=False, compare=False, default=None)
    _dst_ports: tuple[int, int] | None = field(init=False, repr=False, compare=False, default=None)

    def __post_init__(self) -> None:
        def put(name: str, value: Any) -> None:
            object.__setattr__(self, name, value)  # frozen dataclass

        put("action", normalize_action(self.action))
        put("protocol", normalize_protocol(self.protocol))
        put("src_ip", normalize_ip(self.src_ip, "src_ip"))
        put("dst_ip", normalize_ip(self.dst_ip, "dst_ip"))
        put("src_port", normalize_port(self.src_port, "src_port"))
        put("dst_port", normalize_port(self.dst_port, "dst_port"))

        if isinstance(self.priority, bool) or not isinstance(self.priority, int):
            raise RuleValidationError(f"Invalid priority {self.priority!r}: must be an integer")
        if not 1 <= self.priority <= MAX_PRIORITY:
            raise RuleValidationError(f"Invalid priority {self.priority}: must be 1-{MAX_PRIORITY}")
        if isinstance(self.id, bool) or not isinstance(self.id, int) or self.id < 0:
            raise RuleValidationError(f"Invalid id {self.id!r}: must be a non-negative integer")
        if not isinstance(self.enabled, bool):
            raise RuleValidationError(f"Invalid enabled flag {self.enabled!r}: must be true/false")
        if not isinstance(self.description, str) or len(self.description) > MAX_DESCRIPTION_LEN:
            raise RuleValidationError(
                f"Invalid description: must be text up to {MAX_DESCRIPTION_LEN} characters"
            )
        if self.protocol == "ICMP" and (self.src_port != ANY or self.dst_port != ANY):
            raise RuleValidationError("ICMP rules cannot specify ports (ICMP has no ports)")

        put("_src_net", None if self.src_ip == ANY else ipaddress.ip_network(self.src_ip))
        put("_dst_net", None if self.dst_ip == ANY else ipaddress.ip_network(self.dst_ip))
        put("_src_ports", _port_bounds(self.src_port))
        put("_dst_ports", _port_bounds(self.dst_port))

    # -- matching ---------------------------------------------------------- #
    def matches(self, packet: PacketInfo) -> bool:
        """Return True if *every* specified criterion matches the packet."""
        if self.protocol != "ANY" and packet.protocol != self.protocol:
            return False
        if self._src_net is not None and not self._ip_in(self._src_net, packet.src_ip):
            return False
        if self._dst_net is not None and not self._ip_in(self._dst_net, packet.dst_ip):
            return False
        if self._src_ports is not None and not self._port_in(self._src_ports, packet.src_port):
            return False
        if self._dst_ports is not None and not self._port_in(self._dst_ports, packet.dst_port):
            return False
        return True

    @staticmethod
    def _ip_in(network: _IPNetwork, ip_text: str) -> bool:
        address = _parse_ip(ip_text)
        # Mixed IPv4/IPv6 comparisons simply do not match.
        return address is not None and address in network

    @staticmethod
    def _port_in(bounds: tuple[int, int], port: int | None) -> bool:
        return port is not None and bounds[0] <= port <= bounds[1]

    # -- (de)serialisation -------------------------------------------------- #
    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "priority": self.priority,
            "action": self.action,
            "protocol": self.protocol,
            "src_ip": self.src_ip,
            "src_port": self.src_port,
            "dst_ip": self.dst_ip,
            "dst_port": self.dst_port,
            "enabled": self.enabled,
            "description": self.description,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Rule":
        """Build a rule from a dict. Unknown keys are rejected (catches typos)."""
        if not isinstance(data, dict):
            raise RuleValidationError(f"A rule must be a JSON object, got {type(data).__name__}")
        allowed = {f.name for f in fields(cls) if f.init}
        unknown = set(data) - allowed
        if unknown:
            raise RuleValidationError(f"Unknown rule field(s): {', '.join(sorted(unknown))}")
        if "action" not in data:
            raise RuleValidationError("A rule requires an 'action' (ALLOW or BLOCK)")
        return cls(**data)

    def describe(self) -> str:
        """Short human-readable summary, e.g. ``BLOCK TCP src=any:any dst=any:23``."""
        return (
            f"{self.action} {self.protocol} "
            f"src={self.src_ip}:{self.src_port} dst={self.dst_ip}:{self.dst_port}"
        )


# --------------------------------------------------------------------------- #
# Decision
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class Decision:
    """Result of evaluating one packet."""

    action: str  # "ALLOW" or "BLOCK"
    rule: Rule | None  # None => the default policy decided
    reason: str

    @property
    def is_blocked(self) -> bool:
        return self.action == "BLOCK"


# --------------------------------------------------------------------------- #
# RuleSet
# --------------------------------------------------------------------------- #
class RuleSet:
    """An ordered collection of rules plus the default policy."""

    def __init__(
        self,
        rules: list[Rule] | None = None,
        default_policy: str = "ALLOW",
        path: str | Path | None = None,
    ) -> None:
        self.default_policy = normalize_action(default_policy)
        self.path = Path(path) if path else None
        self._rules: list[Rule] = []
        self._ordered: list[Rule] | None = None
        self._mtime_ns: int | None = None
        for rule in rules or []:
            self._insert(rule)

    # -- persistence -------------------------------------------------------- #
    @classmethod
    def load(cls, path: str | Path, create_if_missing: bool = False) -> "RuleSet":
        """Load rules from a JSON file."""
        path = Path(path)
        if not path.exists():
            if not create_if_missing:
                raise RuleFileError(f"Rules file not found: {path}")
            ruleset = cls(path=path)
            ruleset.save()
            return ruleset
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise RuleFileError(f"{path} is not valid JSON: {exc}") from exc
        except OSError as exc:
            raise RuleFileError(f"Cannot read {path}: {exc}") from exc

        if not isinstance(raw, dict):
            raise RuleFileError(f"{path}: top level must be a JSON object")
        rule_dicts = raw.get("rules", [])
        if not isinstance(rule_dicts, list):
            raise RuleFileError(f"{path}: 'rules' must be a list")
        try:
            ruleset = cls(default_policy=raw.get("default_policy", "ALLOW"), path=path)
            for index, rule_dict in enumerate(rule_dicts):
                try:
                    ruleset._insert(Rule.from_dict(rule_dict))
                except RuleValidationError as exc:
                    raise RuleValidationError(f"rules[{index}]: {exc}") from exc
        except RuleValidationError as exc:
            raise RuleFileError(f"{path}: {exc}") from exc
        ruleset._mtime_ns = ruleset._stat_mtime()
        return ruleset

    def save(self) -> None:
        """Atomically write the rules to ``self.path``."""
        if self.path is None:
            raise RuleFileError("This RuleSet has no file path to save to")
        payload = {
            "version": CONFIG_VERSION,
            "default_policy": self.default_policy,
            "rules": [rule.to_dict() for rule in self._rules],
        }
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp_name = tempfile.mkstemp(dir=self.path.parent, prefix=".rules-", suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, indent=2)
                handle.write("\n")
            os.replace(tmp_name, self.path)
        except OSError as exc:
            Path(tmp_name).unlink(missing_ok=True)
            raise RuleFileError(f"Cannot write {self.path}: {exc}") from exc
        self._mtime_ns = self._stat_mtime()

    def _stat_mtime(self) -> int | None:
        try:
            return self.path.stat().st_mtime_ns if self.path else None
        except OSError:
            return None

    def reload_if_changed(self) -> bool:
        """Reload from disk if the file changed. Returns True if rules were replaced.

        On a malformed file the previous rules stay active and ``RuleFileError``
        is raised once for that version of the file.
        """
        if self.path is None:
            return False
        current = self._stat_mtime()
        if current is None or current == self._mtime_ns:
            return False
        self._mtime_ns = current  # don't retry a broken file on every packet
        fresh = RuleSet.load(self.path)
        self._rules = fresh._rules
        self.default_policy = fresh.default_policy
        self._ordered = None
        return True

    # -- administration ----------------------------------------------------- #
    def _next_id(self) -> int:
        return max((rule.id for rule in self._rules), default=0) + 1

    def _insert(self, rule: Rule) -> Rule:
        if rule.id == 0:
            rule = replace(rule, id=self._next_id())
        elif any(existing.id == rule.id for existing in self._rules):
            raise RuleValidationError(f"Duplicate rule id {rule.id}")
        self._rules.append(rule)
        self._ordered = None
        return rule

    def add(self, **fields_: Any) -> Rule:
        """Create and append a rule. Omitted priority => after all existing rules."""
        data = {key: value for key, value in fields_.items() if value is not None}
        if "priority" not in data:
            data["priority"] = max((r.priority for r in self._rules), default=0) + 10
            data["priority"] = min(data["priority"], MAX_PRIORITY)
        return self._insert(Rule.from_dict(data))

    def get(self, rule_id: int) -> Rule:
        for rule in self._rules:
            if rule.id == rule_id:
                return rule
        raise RuleNotFoundError(f"No rule with id {rule_id}")

    def remove(self, rule_id: int) -> Rule:
        rule = self.get(rule_id)
        self._rules.remove(rule)
        self._ordered = None
        return rule

    def update(self, rule_id: int, **changes: Any) -> Rule:
        """Change fields of an existing rule (``None`` values are ignored)."""
        old = self.get(rule_id)
        if "id" in changes and changes["id"] not in (None, rule_id):
            raise RuleValidationError("A rule's id cannot be changed")
        changes = {key: value for key, value in changes.items() if value is not None}
        new = Rule.from_dict({**old.to_dict(), **changes, "id": rule_id})
        self._rules[self._rules.index(old)] = new
        self._ordered = None
        return new

    def list_rules(self) -> list[Rule]:
        """All rules (including disabled) in *evaluation order*."""
        return list(self._sorted())

    def __len__(self) -> int:
        return len(self._rules)

    # -- evaluation ---------------------------------------------------------- #
    def _sorted(self) -> list[Rule]:
        if self._ordered is None:
            indexed = list(enumerate(self._rules))
            indexed.sort(key=lambda pair: (pair[1].priority, _ACTION_RANK[pair[1].action], pair[0]))
            self._ordered = [rule for _, rule in indexed]
        return self._ordered

    def evaluate(self, packet: PacketInfo) -> Decision:
        """Return the decision for ``packet`` using first-match-wins semantics."""
        for rule in self._sorted():
            if rule.enabled and rule.matches(packet):
                verb = "Blocked" if rule.action == "BLOCK" else "Allowed"
                return Decision(rule.action, rule, f"{verb} by rule #{rule.id} ({rule.describe()})")
        verb = "Blocked" if self.default_policy == "BLOCK" else "Allowed"
        return Decision(
            self.default_policy, None, f"{verb} by default policy ({self.default_policy}); no rule matched"
        )
