"""Real-time (or offline) packet capture using Scapy.

Capture needs elevated privileges (root on Linux/macOS, Administrator + Npcap on
Windows). To keep the rest of the project importable and testable without Scapy
or privileges, Scapy is imported lazily.
"""

from __future__ import annotations

import threading
from functools import lru_cache
from typing import Any, Callable

from .models import PacketInfo


class MonitorError(RuntimeError):
    """Packet capture could not be started."""


@lru_cache(maxsize=1)
def _scapy() -> dict[str, Any]:
    try:
        from scapy.all import AsyncSniffer, sniff  # noqa: PLC0415
        from scapy.layers.inet import ICMP, IP, TCP, UDP  # noqa: PLC0415
        from scapy.layers.inet6 import IPv6  # noqa: PLC0415
    except ImportError as exc:
        raise MonitorError(
            "Scapy is not installed. Run: pip install -r requirements.txt"
        ) from exc
    return {
        "AsyncSniffer": AsyncSniffer, "sniff": sniff,
        "IP": IP, "IPv6": IPv6, "TCP": TCP, "UDP": UDP, "ICMP": ICMP,
    }


def parse_packet(pkt: Any) -> PacketInfo | None:
    """Convert a Scapy packet to :class:`PacketInfo` (``None`` for non-IP frames)."""
    s = _scapy()
    if pkt.haslayer(s["IP"]):
        ip = pkt[s["IP"]]
        src, dst = ip.src, ip.dst
        is_icmp = pkt.haslayer(s["ICMP"])
    elif pkt.haslayer(s["IPv6"]):
        ip6 = pkt[s["IPv6"]]
        src, dst = ip6.src, ip6.dst
        is_icmp = ip6.nh == 58  # ICMPv6
    else:
        return None  # ARP, STP, etc. are out of scope

    protocol, src_port, dst_port, flags = "OTHER", None, None, ""
    if pkt.haslayer(s["TCP"]):
        tcp = pkt[s["TCP"]]
        protocol, src_port, dst_port, flags = "TCP", int(tcp.sport), int(tcp.dport), str(tcp.flags)
    elif pkt.haslayer(s["UDP"]):
        udp = pkt[s["UDP"]]
        protocol, src_port, dst_port = "UDP", int(udp.sport), int(udp.dport)
    elif is_icmp:
        protocol = "ICMP"

    return PacketInfo(
        src_ip=str(src), dst_ip=str(dst), protocol=protocol, size=len(pkt),
        src_port=src_port, dst_port=dst_port, timestamp=float(pkt.time), tcp_flags=flags,
    )


class PacketMonitor:
    """Captures packets and hands each parsed :class:`PacketInfo` to ``callback``."""

    def __init__(
        self,
        callback: Callable[[PacketInfo], None],
        iface: str | None = None,
        bpf_filter: str | None = None,
        pcap_file: str | None = None,
    ) -> None:
        self.callback = callback
        self.iface = iface
        self.bpf_filter = bpf_filter
        self.pcap_file = pcap_file

    def _handle(self, pkt: Any) -> None:
        try:
            info = parse_packet(pkt)
        except Exception:  # a single malformed packet must never stop the monitor
            return
        if info is not None:
            self.callback(info)

    def run(self, stop_event: threading.Event) -> None:
        """Block until ``stop_event`` is set (live) or the pcap ends (offline)."""
        s = _scapy()
        try:
            if self.pcap_file:
                s["sniff"](offline=self.pcap_file, prn=self._handle, store=False,
                           filter=self.bpf_filter,
                           stop_filter=lambda _pkt: stop_event.is_set())
                return
            sniffer = s["AsyncSniffer"](
                iface=self.iface, prn=self._handle, store=False, filter=self.bpf_filter
            )
            sniffer.start()
            try:
                while not stop_event.is_set():
                    if sniffer.thread is not None and not sniffer.thread.is_alive():
                        # Sniffer thread died (e.g. permission error / bad interface).
                        detail = getattr(sniffer, "exception", None)
                        raise MonitorError(
                            f"Packet capture stopped unexpectedly ({detail or 'no details'}). "
                            "Check privileges, interface name and Npcap/libpcap.")
                    stop_event.wait(0.5)
            finally:
                if getattr(sniffer, "running", False):
                    sniffer.stop()
        except PermissionError as exc:
            raise MonitorError("Permission denied: packet capture needs root/Administrator.") from exc
        except OSError as exc:
            raise MonitorError(f"Capture error: {exc}") from exc
