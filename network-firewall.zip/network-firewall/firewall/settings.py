"""Application settings (``config/settings.json``) - kept apart from rules and logic."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .threat_detector import ThreatConfig, ThreatConfigError


class SettingsError(ValueError):
    """The settings file is malformed."""


_KNOWN_KEYS = {
    "log_file", "log_allowed_packets", "log_max_bytes", "log_backup_count",
    "run_dir", "threat_detection",
}


@dataclass
class Settings:
    """Runtime settings. Relative paths are resolved against ``base_dir``."""

    base_dir: Path
    log_file: Path
    run_dir: Path
    log_allowed_packets: bool = True
    log_max_bytes: int = 5_000_000
    log_backup_count: int = 3
    threat: ThreatConfig = field(default_factory=ThreatConfig)

    @property
    def pid_file(self) -> Path:
        return self.run_dir / "firewall.pid"

    @property
    def status_file(self) -> Path:
        return self.run_dir / "status.json"

    @property
    def console_file(self) -> Path:
        return self.run_dir / "console.out"

    @classmethod
    def load(cls, path: str | Path | None, base_dir: str | Path) -> "Settings":
        """Load settings; a missing file yields the defaults."""
        base = Path(base_dir).resolve()
        data: dict[str, Any] = {}
        if path and Path(path).exists():
            try:
                data = json.loads(Path(path).read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError) as exc:
                raise SettingsError(f"Cannot read settings file {path}: {exc}") from exc
            if not isinstance(data, dict):
                raise SettingsError(f"{path}: top level must be a JSON object")
        unknown = set(data) - _KNOWN_KEYS
        if unknown:
            raise SettingsError(f"Unknown setting(s): {', '.join(sorted(unknown))}")

        def resolve(value: str) -> Path:
            candidate = Path(value)
            return candidate if candidate.is_absolute() else base / candidate

        try:
            threat = ThreatConfig.from_dict(data.get("threat_detection", {}))
        except ThreatConfigError as exc:
            raise SettingsError(str(exc)) from exc

        for key in ("log_max_bytes", "log_backup_count"):
            value = data.get(key, 1)
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise SettingsError(f"'{key}' must be a non-negative integer")
        if not isinstance(data.get("log_allowed_packets", True), bool):
            raise SettingsError("'log_allowed_packets' must be true or false")

        return cls(
            base_dir=base,
            log_file=resolve(data.get("log_file", "logs/firewall.log")),
            run_dir=resolve(data.get("run_dir", "run")),
            log_allowed_packets=data.get("log_allowed_packets", True),
            log_max_bytes=data.get("log_max_bytes", 5_000_000),
            log_backup_count=data.get("log_backup_count", 3),
            threat=threat,
        )
