"""Packet filter: evaluates each packet, logs the decision and runs threat detection.

IMPORTANT - what "BLOCK" means here
-----------------------------------
This class makes a *decision* and records it. Scapy sniffs a **copy** of traffic
that the OS has already delivered, so nothing is actually dropped. Real packet
dropping needs the OS firewall (see ``enforcer.py``, which generates iptables
commands for an administrator to review and apply).
"""

from __future__ import annotations

import logging
import time
from dataclasses import asdict, dataclass

from .logger import FirewallLogger
from .models import PacketInfo
from .rule_engine import Decision, RuleError, RuleSet
from .threat_detector import ThreatAlert, ThreatDetector


@dataclass
class FilterStats:
    """Running counters, exposed by the ``status`` command."""

    total: int = 0
    allowed: int = 0
    blocked: int = 0
    alerts: int = 0

    def to_dict(self) -> dict[str, int]:
        return asdict(self)


@dataclass(frozen=True)
class FilterResult:
    """Everything that happened to one packet."""

    packet: PacketInfo
    decision: Decision
    alerts: tuple[ThreatAlert, ...] = ()


class PacketFilter:
    """Coordinates rule evaluation, logging and threat detection."""

    def __init__(
        self,
        ruleset: RuleSet,
        logger: FirewallLogger,
        detector: ThreatDetector | None = None,
        *,
        log_allowed: bool = True,
        reload_interval: float = 2.0,
    ) -> None:
        self.ruleset = ruleset
        self.logger = logger
        self.detector = detector
        self.log_allowed = log_allowed
        self.reload_interval = reload_interval
        self.stats = FilterStats()
        self._last_reload_check = time.monotonic()

    def process(self, packet: PacketInfo) -> FilterResult:
        """Evaluate one packet and return the decision plus any threat alerts."""
        self._maybe_reload_rules()
        decision = self.ruleset.evaluate(packet)

        self.stats.total += 1
        if decision.is_blocked:
            self.stats.blocked += 1
        else:
            self.stats.allowed += 1
        if decision.is_blocked or self.log_allowed:
            self.logger.log_decision(packet, decision)

        alerts: tuple[ThreatAlert, ...] = ()
        if self.detector is not None:
            alerts = tuple(self.detector.observe(packet, blocked=decision.is_blocked))
            for alert in alerts:
                self.logger.log_alert(alert)
            self.stats.alerts += len(alerts)
        return FilterResult(packet, decision, alerts)

    def _maybe_reload_rules(self) -> None:
        """Pick up rule changes made with ``add-rule`` etc. while running."""
        now = time.monotonic()
        if now - self._last_reload_check < self.reload_interval:
            return
        self._last_reload_check = now
        try:
            if self.ruleset.reload_if_changed():
                self.logger.log_event(f"Rules reloaded ({len(self.ruleset)} rules)")
        except RuleError as exc:
            self.logger.log_event(
                f"Rules file changed but could not be loaded; keeping previous rules: {exc}",
                logging.ERROR,
            )
