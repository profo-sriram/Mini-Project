"""Basic rule-based threat detection using per-source sliding windows.

Detections (all thresholds are configurable in ``config/settings.json``):

========================  ====================================================
Alert type                Trigger (within ``window_seconds``, per source IP)
========================  ====================================================
``PORT_SCAN``             >= N distinct destination ports contacted
``REPEATED_CONNECTIONS``  >= N TCP SYN attempts to the same destination:port
``BLOCKED_TRAFFIC``       >= N packets that the rules BLOCKED
``EXCESSIVE_TRAFFIC``     >= N packets of any kind
========================  ====================================================

An alert for the same (type, source) is suppressed for ``alert_cooldown_seconds``
to avoid flooding the log. Memory use is bounded (per-source and global caps).
These are simple heuristics for a lab, not a replacement for an IDS.
"""

from __future__ import annotations

from collections import Counter, deque
from dataclasses import dataclass, field, fields
from typing import Any

from .models import PacketInfo

PORT_SCAN = "PORT_SCAN"
REPEATED_CONNECTIONS = "REPEATED_CONNECTIONS"
BLOCKED_TRAFFIC = "BLOCKED_TRAFFIC"
EXCESSIVE_TRAFFIC = "EXCESSIVE_TRAFFIC"


class ThreatConfigError(ValueError):
    """Invalid threat-detection configuration."""


@dataclass
class ThreatConfig:
    """Detection thresholds. Defaults are tuned for a small lab network."""

    enabled: bool = True
    window_seconds: float = 10.0
    port_scan_threshold: int = 15
    repeated_attempt_threshold: int = 10
    blocked_attempt_threshold: int = 5
    packet_rate_threshold: int = 200
    alert_cooldown_seconds: float = 30.0
    max_tracked_sources: int = 10_000
    max_events_per_source: int = 5_000

    def __post_init__(self) -> None:
        if not isinstance(self.enabled, bool):
            raise ThreatConfigError("'enabled' must be true or false")
        for f in fields(self):
            if f.name == "enabled":
                continue
            value = getattr(self, f.name)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or value <= 0:
                raise ThreatConfigError(f"'{f.name}' must be a positive number, got {value!r}")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ThreatConfig":
        if not isinstance(data, dict):
            raise ThreatConfigError("'threat_detection' must be a JSON object")
        unknown = set(data) - {f.name for f in fields(cls)}
        if unknown:
            raise ThreatConfigError(f"Unknown threat_detection key(s): {', '.join(sorted(unknown))}")
        return cls(**data)


@dataclass(frozen=True)
class ThreatAlert:
    """A suspicious-activity warning."""

    timestamp: float
    kind: str
    src_ip: str
    message: str


@dataclass
class _SourceState:
    """Sliding-window state for one source IP (counters are updated incrementally)."""

    events: deque = field(default_factory=deque)  # (ts, dst_ip, dst_port, is_syn, blocked)
    port_counts: Counter = field(default_factory=Counter)
    syn_counts: Counter = field(default_factory=Counter)
    blocked: int = 0
    last_seen: float = 0.0

    def add(self, ts: float, packet: PacketInfo, blocked: bool) -> None:
        syn = packet.is_syn
        self.events.append((ts, packet.dst_ip, packet.dst_port, syn, blocked))
        if packet.dst_port is not None:
            self.port_counts[(packet.dst_ip, packet.dst_port)] += 1
        if syn and packet.dst_port is not None:
            self.syn_counts[(packet.dst_ip, packet.dst_port)] += 1
        self.blocked += int(blocked)
        self.last_seen = ts

    def _pop_oldest(self) -> None:
        _, dst_ip, dst_port, syn, blocked = self.events.popleft()
        key = (dst_ip, dst_port)
        if dst_port is not None:
            self._decrement(self.port_counts, key)
        if syn and dst_port is not None:
            self._decrement(self.syn_counts, key)
        self.blocked -= int(blocked)

    @staticmethod
    def _decrement(counter: Counter, key: tuple) -> None:
        counter[key] -= 1
        if counter[key] <= 0:
            del counter[key]

    def expire(self, now: float, window: float, max_events: int) -> None:
        while self.events and (self.events[0][0] <= now - window or len(self.events) > max_events):
            self._pop_oldest()


class ThreatDetector:
    """Feed it every packet via :meth:`observe`; it returns any new alerts."""

    _CLEANUP_EVERY = 1000  # packets

    def __init__(self, config: ThreatConfig | None = None) -> None:
        self.config = config or ThreatConfig()
        self._sources: dict[str, _SourceState] = {}
        self._last_alert: dict[tuple[str, str], float] = {}
        self._seen = 0

    def observe(self, packet: PacketInfo, blocked: bool) -> list[ThreatAlert]:
        """Record one packet (and whether the firewall blocked it); return new alerts."""
        cfg = self.config
        if not cfg.enabled:
            return []
        now = packet.timestamp
        state = self._sources.get(packet.src_ip)
        if state is None:
            state = self._sources[packet.src_ip] = _SourceState()
            self._enforce_source_cap()
        state.expire(now, cfg.window_seconds, cfg.max_events_per_source)
        state.add(now, packet, blocked)

        self._seen += 1
        if self._seen % self._CLEANUP_EVERY == 0:
            self._cleanup(now)

        alerts: list[ThreatAlert] = []
        window = f"{cfg.window_seconds:g}s"

        distinct_ports = len({port for (_, port) in state.port_counts})
        if distinct_ports >= cfg.port_scan_threshold:
            self._raise(alerts, now, PORT_SCAN, packet.src_ip,
                        f"possible port scan: {distinct_ports} distinct destination ports in {window}")

        if state.syn_counts:
            target, count = state.syn_counts.most_common(1)[0]
            if count >= cfg.repeated_attempt_threshold:
                self._raise(alerts, now, REPEATED_CONNECTIONS, packet.src_ip,
                            f"{count} connection attempts (SYN) to {target[0]}:{target[1]} in {window}")

        if state.blocked >= cfg.blocked_attempt_threshold:
            self._raise(alerts, now, BLOCKED_TRAFFIC, packet.src_ip,
                        f"{state.blocked} packets hit BLOCK rules in {window}")

        if len(state.events) >= cfg.packet_rate_threshold:
            self._raise(alerts, now, EXCESSIVE_TRAFFIC, packet.src_ip,
                        f"{len(state.events)} packets in {window}")
        return alerts

    # -- internals ----------------------------------------------------------- #
    def _raise(self, out: list[ThreatAlert], now: float, kind: str, src: str, message: str) -> None:
        key = (kind, src)
        last = self._last_alert.get(key)
        if last is not None and now - last < self.config.alert_cooldown_seconds:
            return
        self._last_alert[key] = now
        out.append(ThreatAlert(timestamp=now, kind=kind, src_ip=src, message=message))

    def _cleanup(self, now: float) -> None:
        """Drop idle sources and stale cooldown entries to bound memory."""
        window = self.config.window_seconds
        for ip in [ip for ip, s in self._sources.items() if now - s.last_seen > window]:
            del self._sources[ip]
        cooldown = self.config.alert_cooldown_seconds
        for key in [k for k, ts in self._last_alert.items() if now - ts > cooldown]:
            del self._last_alert[key]

    def _enforce_source_cap(self) -> None:
        cap = self.config.max_tracked_sources
        if len(self._sources) <= cap:
            return
        oldest = sorted(self._sources, key=lambda ip: self._sources[ip].last_seen)
        for ip in oldest[: max(1, cap // 10)]:  # evict the least recently seen 10%
            del self._sources[ip]

    @property
    def tracked_sources(self) -> int:
        return len(self._sources)
