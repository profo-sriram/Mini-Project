"""Shared data models used across the firewall modules."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from datetime import datetime


def format_endpoint(ip: str, port: int | None) -> str:
    """Return ``ip:port`` (``[ip]:port`` for IPv6) or just ``ip`` if no port."""
    if port is None:
        return ip
    return f"[{ip}]:{port}" if ":" in ip else f"{ip}:{port}"


@dataclass(frozen=True)
class PacketInfo:
    """The subset of packet metadata the firewall cares about.

    Only headers are inspected; payloads are never read or stored.
    """

    src_ip: str
    dst_ip: str
    protocol: str  # "TCP", "UDP", "ICMP" or "OTHER"
    size: int = 0
    src_port: int | None = None
    dst_port: int | None = None
    timestamp: float = field(default_factory=time.time)
    tcp_flags: str = ""  # e.g. "S", "SA", "PA" (TCP only)

    @property
    def is_syn(self) -> bool:
        """True for a TCP connection attempt (SYN set, ACK not set)."""
        return self.protocol == "TCP" and "S" in self.tcp_flags and "A" not in self.tcp_flags

    @property
    def time_str(self) -> str:
        """Local wall-clock time, ``YYYY-MM-DD HH:MM:SS``."""
        return datetime.fromtimestamp(self.timestamp).strftime("%Y-%m-%d %H:%M:%S")

    @property
    def src_endpoint(self) -> str:
        return format_endpoint(self.src_ip, self.src_port)

    @property
    def dst_endpoint(self) -> str:
        return format_endpoint(self.dst_ip, self.dst_port)
