"""Real-time, structured logging to ``logs/firewall.log``.

Line format (``|``-separated, ``key=value`` fields so it is easy to grep/parse)::

    2026-10-01 14:03:11 | INFO    | BLOCKED | proto=TCP | src_ip=... | src_port=... |
        dst_ip=... | dst_port=... | size=60 | rule=#2 | reason=...
    2026-10-01 14:03:12 | WARNING | THREAT  | type=PORT_SCAN | src_ip=... | details=...

The record time is the *packet* time, so replaying a pcap logs the original times.
"""

from __future__ import annotations

import logging
import time
from collections import deque
from datetime import datetime
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Iterator

from .models import PacketInfo
from .rule_engine import Decision
from .threat_detector import ThreatAlert


def _fmt_time(timestamp: float) -> str:
    return datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M:%S")


def _val(value: object) -> str:
    return "-" if value is None else str(value)


def format_decision(packet: PacketInfo, decision: Decision) -> str:
    """Build the log line for one filtering decision."""
    status = "BLOCKED" if decision.is_blocked else "ALLOWED"
    rule = f"#{decision.rule.id}" if decision.rule else "default-policy"
    return (
        f"{packet.time_str} | INFO    | {status:<7} | proto={packet.protocol} "
        f"| src_ip={packet.src_ip} | src_port={_val(packet.src_port)} "
        f"| dst_ip={packet.dst_ip} | dst_port={_val(packet.dst_port)} "
        f"| size={packet.size} | rule={rule} | reason={decision.reason}"
    )


def format_alert(alert: ThreatAlert) -> str:
    """Build the log line for a threat-detection warning."""
    return (
        f"{_fmt_time(alert.timestamp)} | WARNING | THREAT  | type={alert.kind} "
        f"| src_ip={alert.src_ip} | details={alert.message}"
    )


class FirewallLogger:
    """Thin wrapper around a rotating file handler.

    Call :meth:`close` when finished (important on Windows, where open files
    cannot be deleted).
    """

    def __init__(
        self,
        log_path: str | Path,
        max_bytes: int = 5_000_000,
        backup_count: int = 3,
    ) -> None:
        self.log_path = Path(log_path)
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        # One logger object per log file; reset handlers to avoid duplicate lines.
        self._logger = logging.getLogger(f"pyfirewall.{self.log_path.resolve()}")
        self._logger.setLevel(logging.INFO)
        self._logger.propagate = False
        for old in list(self._logger.handlers):
            self._logger.removeHandler(old)
            old.close()
        self._handler = RotatingFileHandler(
            self.log_path, maxBytes=max_bytes, backupCount=backup_count, encoding="utf-8"
        )
        self._handler.setFormatter(logging.Formatter("%(message)s"))
        self._logger.addHandler(self._handler)

    def log_decision(self, packet: PacketInfo, decision: Decision) -> None:
        self._logger.info(format_decision(packet, decision))

    def log_alert(self, alert: ThreatAlert) -> None:
        self._logger.warning(format_alert(alert))

    def log_event(self, message: str, level: int = logging.INFO) -> None:
        """Log a system event (startup, shutdown, rules reloaded, errors...)."""
        name = logging.getLevelName(level)
        self._logger.log(level, f"{_fmt_time(time.time())} | {name:<7} | SYSTEM  | {message}")

    def close(self) -> None:
        self._logger.removeHandler(self._handler)
        self._handler.close()


# --------------------------------------------------------------------------- #
# Helpers for the ``logs`` CLI command
# --------------------------------------------------------------------------- #
def tail_log(path: str | Path, lines: int = 20, contains: str | None = None) -> list[str]:
    """Return the last ``lines`` log lines, optionally only those containing a text."""
    path = Path(path)
    if not path.exists():
        return []
    buffer: deque[str] = deque(maxlen=max(lines, 0))
    with path.open("r", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            if contains is None or contains in line:
                buffer.append(line.rstrip("\n"))
    return list(buffer)


def follow_log(
    path: str | Path, contains: str | None = None, poll_seconds: float = 0.5
) -> Iterator[str]:
    """Yield new log lines as they are written (like ``tail -f``). Ctrl+C to stop."""
    path = Path(path)
    while not path.exists():
        time.sleep(poll_seconds)
    with path.open("r", encoding="utf-8", errors="replace") as handle:
        handle.seek(0, 2)  # jump to end
        while True:
            line = handle.readline()
            if line:
                if contains is None or contains in line:
                    yield line.rstrip("\n")
                continue
            time.sleep(poll_seconds)
            try:  # log rotated/truncated -> start from the beginning again
                if path.stat().st_size < handle.tell():
                    handle.seek(0)
            except OSError:
                pass
