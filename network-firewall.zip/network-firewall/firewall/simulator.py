"""Synthetic traffic for demos and tests - needs no privileges and no Scapy.

Run with ``python main.py simulate``. It produces a mix of normal and suspicious
packets (all clearly labelled lab addresses) so the rule engine, logger and
threat detector can be demonstrated safely on any machine.
"""

from __future__ import annotations

import time

from .models import PacketInfo

LAB_HOST = "10.0.0.5"


def generate_demo_packets(start: float | None = None) -> list[PacketInfo]:
    """Return a deterministic list of demo packets with increasing timestamps."""
    t = start if start is not None else time.time()
    packets: list[PacketInfo] = []

    def add(src: str, dst: str, proto: str, sport: int | None, dport: int | None,
            size: int = 60, flags: str = "") -> None:
        nonlocal t
        t += 0.05
        packets.append(PacketInfo(src, dst, proto, size, sport, dport, t, flags))

    # Normal traffic
    add("10.0.0.20", LAB_HOST, "TCP", 50001, 80, 74, "S")
    add("10.0.0.20", LAB_HOST, "TCP", 50002, 443, 74, "S")
    add("10.0.0.21", LAB_HOST, "UDP", 40000, 53, 82)
    add("10.0.0.22", LAB_HOST, "ICMP", None, None, 98)
    # Telnet attempt and a blocked host
    add("10.0.0.30", LAB_HOST, "TCP", 50100, 23, 60, "S")
    add("192.168.1.100", LAB_HOST, "TCP", 51234, 8080, 60, "S")
    # Port scan from one source
    for port in range(1, 21):
        add("10.0.0.66", LAB_HOST, "TCP", 40000 + port, port, 44, "S")
    # Repeated connection attempts (SYN burst) to SSH
    for i in range(12):
        add("10.0.0.77", LAB_HOST, "TCP", 41000 + i, 22, 60, "S")
    # Repeated hits on a blocked port
    for i in range(6):
        add("10.0.0.88", LAB_HOST, "TCP", 42000 + i, 23, 60, "S")
    return packets
