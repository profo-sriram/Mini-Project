"""Process bookkeeping for ``start`` / ``stop`` / ``status`` (PID + status files)."""

from __future__ import annotations

import json
import os
import signal
import sys
import time
from pathlib import Path
from typing import Any


def write_pid(pid_file: Path, pid: int | None = None) -> None:
    pid_file.parent.mkdir(parents=True, exist_ok=True)
    pid_file.write_text(str(pid if pid is not None else os.getpid()), encoding="utf-8")


def read_pid(pid_file: Path) -> int | None:
    try:
        return int(pid_file.read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        return None


def is_process_running(pid: int) -> bool:
    """Check whether a process exists *without* signalling it."""
    if pid <= 0:
        return False
    if sys.platform == "win32":
        # os.kill(pid, 0) would TERMINATE the process on Windows, so use the Win32 API.
        import ctypes  # noqa: PLC0415

        kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
        handle = kernel32.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
        if not handle:
            return False
        try:
            code = ctypes.c_ulong()
            ok = kernel32.GetExitCodeProcess(handle, ctypes.byref(code))
            return bool(ok) and code.value == 259  # STILL_ACTIVE
        finally:
            kernel32.CloseHandle(handle)
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True  # exists, owned by someone else
    return True


def running_pid(pid_file: Path) -> int | None:
    """Return the PID of a live firewall process, cleaning up a stale PID file."""
    pid = read_pid(pid_file)
    if pid is None:
        return None
    if is_process_running(pid):
        return pid
    pid_file.unlink(missing_ok=True)
    return None


def stop_process(pid_file: Path, timeout: float = 5.0) -> bool:
    """Ask the firewall process to stop (SIGTERM). Returns True once it has exited."""
    pid = running_pid(pid_file)
    if pid is None:
        return True
    os.kill(pid, signal.SIGTERM)
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if not is_process_running(pid):
            pid_file.unlink(missing_ok=True)
            return True
        time.sleep(0.1)
    return False


def write_status(status_file: Path, data: dict[str, Any]) -> None:
    status_file.parent.mkdir(parents=True, exist_ok=True)
    tmp = status_file.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    os.replace(tmp, status_file)


def read_status(status_file: Path) -> dict[str, Any] | None:
    try:
        return json.loads(status_file.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
