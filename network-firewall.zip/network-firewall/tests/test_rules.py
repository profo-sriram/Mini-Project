"""Tests for rule parsing/validation, matching, precedence and persistence."""

import json
import tempfile
import unittest
from pathlib import Path

from firewall.rule_engine import (
    Rule, RuleFileError, RuleNotFoundError, RuleSet, RuleValidationError,
)
from tests.helpers import make_packet


def ruleset(*rules: dict, default: str = "ALLOW") -> RuleSet:
    rs = RuleSet(default_policy=default)
    for rule in rules:
        rs.add(**rule)
    return rs


class IpRuleTests(unittest.TestCase):
    def test_exact_source_ip_blocks(self):
        rs = ruleset({"action": "BLOCK", "src_ip": "192.168.1.100"})
        self.assertTrue(rs.evaluate(make_packet(src_ip="192.168.1.100")).is_blocked)
        self.assertFalse(rs.evaluate(make_packet(src_ip="192.168.1.101")).is_blocked)

    def test_destination_ip_rule(self):
        rs = ruleset({"action": "BLOCK", "dst_ip": "8.8.8.8"})
        self.assertTrue(rs.evaluate(make_packet(dst_ip="8.8.8.8")).is_blocked)
        self.assertFalse(rs.evaluate(make_packet(dst_ip="8.8.4.4")).is_blocked)

    def test_cidr_range(self):
        rs = ruleset({"action": "BLOCK", "src_ip": "10.1.0.0/16"})
        self.assertTrue(rs.evaluate(make_packet(src_ip="10.1.200.7")).is_blocked)
        self.assertFalse(rs.evaluate(make_packet(src_ip="10.2.0.1")).is_blocked)

    def test_ipv6_and_family_mismatch(self):
        rs = ruleset({"action": "BLOCK", "src_ip": "2001:db8::/32"})
        self.assertTrue(rs.evaluate(make_packet(src_ip="2001:db8::1")).is_blocked)
        self.assertFalse(rs.evaluate(make_packet(src_ip="10.0.0.1")).is_blocked)

    def test_host_bits_in_cidr_rejected(self):
        with self.assertRaises(RuleValidationError):
            Rule(action="BLOCK", src_ip="192.168.1.5/24")


class PortRuleTests(unittest.TestCase):
    def test_destination_port(self):
        rs = ruleset({"action": "BLOCK", "protocol": "TCP", "dst_port": 23})
        self.assertTrue(rs.evaluate(make_packet(dst_port=23)).is_blocked)
        self.assertFalse(rs.evaluate(make_packet(dst_port=22)).is_blocked)

    def test_source_port(self):
        rs = ruleset({"action": "BLOCK", "src_port": "4444"})
        self.assertTrue(rs.evaluate(make_packet(src_port=4444)).is_blocked)
        self.assertFalse(rs.evaluate(make_packet(src_port=4445)).is_blocked)

    def test_port_range_inclusive(self):
        rs = ruleset({"action": "BLOCK", "dst_port": "8000-8100"})
        for port, blocked in ((7999, False), (8000, True), (8050, True), (8100, True), (8101, False)):
            self.assertEqual(rs.evaluate(make_packet(dst_port=port)).is_blocked, blocked, port)

    def test_port_rule_never_matches_icmp(self):
        rs = ruleset({"action": "BLOCK", "dst_port": 80})
        self.assertFalse(rs.evaluate(make_packet(protocol="ICMP")).is_blocked)


class ProtocolRuleTests(unittest.TestCase):
    def test_protocol_specific(self):
        rs = ruleset({"action": "BLOCK", "protocol": "udp", "dst_port": 53})
        self.assertTrue(rs.evaluate(make_packet(protocol="UDP", dst_port=53)).is_blocked)
        self.assertFalse(rs.evaluate(make_packet(protocol="TCP", dst_port=53)).is_blocked)

    def test_icmp_rule(self):
        rs = ruleset({"action": "BLOCK", "protocol": "ICMP"})
        self.assertTrue(rs.evaluate(make_packet(protocol="ICMP")).is_blocked)
        self.assertFalse(rs.evaluate(make_packet(protocol="TCP")).is_blocked)

    def test_any_protocol_matches_other(self):
        rs = ruleset({"action": "BLOCK", "src_ip": "10.0.0.2"})
        pkt = make_packet(protocol="OTHER", src_port=None, dst_port=None)
        self.assertTrue(rs.evaluate(pkt).is_blocked)


class DecisionTests(unittest.TestCase):
    def test_allow_and_block_decisions_and_reason(self):
        rs = ruleset({"action": "ALLOW", "protocol": "TCP", "dst_port": 443})
        decision = rs.evaluate(make_packet(dst_port=443))
        self.assertEqual(decision.action, "ALLOW")
        self.assertEqual(decision.rule.id, 1)
        self.assertIn("rule #1", decision.reason)

    def test_default_policy_allow_and_block(self):
        pkt = make_packet(dst_port=9999)
        allow = RuleSet(default_policy="ALLOW").evaluate(pkt)
        block = RuleSet(default_policy="BLOCK").evaluate(pkt)
        self.assertEqual((allow.action, allow.rule), ("ALLOW", None))
        self.assertEqual((block.action, block.rule), ("BLOCK", None))
        self.assertIn("default policy", block.reason)

    def test_disabled_rule_ignored(self):
        rs = ruleset({"action": "BLOCK", "dst_port": 80, "enabled": False})
        self.assertFalse(rs.evaluate(make_packet(dst_port=80)).is_blocked)


class PrecedenceTests(unittest.TestCase):
    def test_lower_priority_number_wins(self):
        rs = ruleset(
            {"action": "BLOCK", "dst_port": 80, "priority": 50},
            {"action": "ALLOW", "dst_port": 80, "priority": 10},
        )
        self.assertEqual(rs.evaluate(make_packet(dst_port=80)).action, "ALLOW")

    def test_block_beats_allow_on_equal_priority(self):
        rs = ruleset(
            {"action": "ALLOW", "dst_port": 80, "priority": 20},
            {"action": "BLOCK", "dst_port": 80, "priority": 20},
        )
        self.assertEqual(rs.evaluate(make_packet(dst_port=80)).action, "BLOCK")

    def test_file_order_breaks_remaining_ties(self):
        rs = ruleset(
            {"action": "BLOCK", "dst_port": "1-100", "priority": 20},
            {"action": "BLOCK", "dst_port": "80", "priority": 20},
        )
        self.assertEqual(rs.evaluate(make_packet(dst_port=80)).rule.id, 1)

    def test_specific_allow_before_broad_block(self):
        rs = ruleset(
            {"action": "ALLOW", "src_ip": "10.0.0.2", "priority": 10},
            {"action": "BLOCK", "src_ip": "10.0.0.0/24", "priority": 20},
        )
        self.assertFalse(rs.evaluate(make_packet(src_ip="10.0.0.2")).is_blocked)
        self.assertTrue(rs.evaluate(make_packet(src_ip="10.0.0.3")).is_blocked)

    def test_list_rules_returns_evaluation_order(self):
        rs = ruleset(
            {"action": "ALLOW", "priority": 30},
            {"action": "BLOCK", "priority": 10},
            {"action": "ALLOW", "priority": 10},
        )
        self.assertEqual([r.id for r in rs.list_rules()], [2, 3, 1])


class InvalidRuleTests(unittest.TestCase):
    def test_invalid_values_rejected(self):
        bad = [
            {"action": "MAYBE"},
            {"action": "BLOCK", "protocol": "GRE"},
            {"action": "BLOCK", "src_ip": "999.1.1.1"},
            {"action": "BLOCK", "dst_ip": "not-an-ip"},
            {"action": "BLOCK", "dst_port": 0},
            {"action": "BLOCK", "dst_port": 70000},
            {"action": "BLOCK", "dst_port": "abc"},
            {"action": "BLOCK", "dst_port": "100-50"},
            {"action": "BLOCK", "dst_port": True},
            {"action": "BLOCK", "dst_port": 80.5},
            {"action": "BLOCK", "priority": 0},
            {"action": "BLOCK", "priority": "high"},
            {"action": "BLOCK", "enabled": "yes"},
            {"action": "BLOCK", "protocol": "ICMP", "dst_port": 80},
            {"action": "BLOCK", "description": "x" * 500},
        ]
        for data in bad:
            with self.subTest(data=data), self.assertRaises(RuleValidationError):
                Rule.from_dict(data)

    def test_missing_action_and_unknown_field(self):
        with self.assertRaises(RuleValidationError):
            Rule.from_dict({"protocol": "TCP"})
        with self.assertRaises(RuleValidationError):
            Rule.from_dict({"action": "BLOCK", "dst_prot": 80})  # typo must not be ignored

    def test_normalisation(self):
        rule = Rule.from_dict({"action": "block", "protocol": "tcp", "dst_port": " 80 ",
                               "src_ip": "*", "dst_ip": "192.168.1.1"})
        self.assertEqual((rule.action, rule.protocol, rule.dst_port, rule.src_ip),
                         ("BLOCK", "TCP", "80", "any"))


class RuleSetAdminTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.path = Path(self._tmp.name) / "rules.json"

    def test_add_list_update_remove_roundtrip(self):
        rs = RuleSet(path=self.path)
        first = rs.add(action="BLOCK", protocol="TCP", dst_port=23)
        second = rs.add(action="ALLOW", protocol="TCP", dst_port=80)
        self.assertEqual((first.id, second.id), (1, 2))
        self.assertGreater(second.priority, first.priority)  # appended after existing rules

        updated = rs.update(1, dst_port=2323, enabled=False)
        self.assertEqual((updated.dst_port, updated.enabled, updated.id), ("2323", False, 1))

        rs.save()
        reloaded = RuleSet.load(self.path)
        self.assertEqual([r.to_dict() for r in reloaded.list_rules()],
                         [r.to_dict() for r in rs.list_rules()])

        reloaded.remove(2)
        self.assertEqual(len(reloaded), 1)
        with self.assertRaises(RuleNotFoundError):
            reloaded.remove(2)
        with self.assertRaises(RuleNotFoundError):
            reloaded.update(42, dst_port=1)

    def test_failed_update_leaves_rule_unchanged(self):
        rs = RuleSet()
        rs.add(action="BLOCK", protocol="TCP", dst_port=23)
        with self.assertRaises(RuleValidationError):
            rs.update(1, protocol="ICMP")  # would leave a port on an ICMP rule
        self.assertEqual(rs.get(1).protocol, "TCP")

    def test_ids_not_reused_in_a_session_and_unique(self):
        rs = RuleSet()
        rs.add(action="BLOCK")
        rs.add(action="BLOCK")
        rs.remove(1)
        self.assertEqual(rs.add(action="ALLOW").id, 3)
        with self.assertRaises(RuleValidationError):
            rs.add(action="ALLOW", id=2)

    def test_load_errors(self):
        with self.assertRaises(RuleFileError):  # missing
            RuleSet.load(self.path)
        self.path.write_text("{ not json", encoding="utf-8")
        with self.assertRaises(RuleFileError):  # malformed JSON
            RuleSet.load(self.path)
        self.path.write_text(json.dumps({"rules": [{"action": "BLOCK", "dst_port": 99999}]}))
        with self.assertRaisesRegex(RuleFileError, r"rules\[0\]"):  # invalid rule, with index
            RuleSet.load(self.path)
        self.path.write_text(json.dumps({"default_policy": "DENY", "rules": []}))
        with self.assertRaises(RuleFileError):  # invalid default policy
            RuleSet.load(self.path)
        self.path.write_text(json.dumps({"rules": [{"id": 1, "action": "BLOCK"},
                                                   {"id": 1, "action": "ALLOW"}]}))
        with self.assertRaises(RuleFileError):  # duplicate ids
            RuleSet.load(self.path)

    def test_create_if_missing(self):
        rs = RuleSet.load(self.path, create_if_missing=True)
        self.assertTrue(self.path.exists())
        self.assertEqual(len(rs), 0)

    def test_shipped_sample_rules_match_spec_examples(self):
        sample = Path(__file__).resolve().parents[1] / "config" / "rules.json"
        rs = RuleSet.load(sample)
        cases = [
            (make_packet(src_ip="192.168.1.100", dst_port=8080), "BLOCK"),
            (make_packet(dst_port=23), "BLOCK"),
            (make_packet(dst_port=80), "ALLOW"),
            (make_packet(dst_port=443), "ALLOW"),
            (make_packet(protocol="UDP", dst_port=53), "BLOCK"),
        ]
        for packet, expected in cases:
            self.assertEqual(rs.evaluate(packet).action, expected, packet)

    def test_reload_if_changed_picks_up_edits(self):
        rs = RuleSet(path=self.path)
        rs.add(action="BLOCK", dst_port=1)
        rs.save()
        other = RuleSet.load(self.path)
        rs.add(action="BLOCK", dst_port=2)
        rs.save()
        import os
        stat = self.path.stat()
        os.utime(self.path, ns=(stat.st_atime_ns, stat.st_mtime_ns + 10_000_000))
        self.assertTrue(other.reload_if_changed())
        self.assertEqual(len(other), 2)
        self.assertFalse(other.reload_if_changed())


if __name__ == "__main__":
    unittest.main()
