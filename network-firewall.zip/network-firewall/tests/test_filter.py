"""Integration tests: PacketFilter + RuleSet + logger + detector, and the iptables exporter."""

import json
import os
import tempfile
import unittest
from pathlib import Path

from firewall.enforcer import generate_script
from firewall.logger import FirewallLogger
from firewall.packet_filter import PacketFilter
from firewall.rule_engine import RuleSet
from firewall.simulator import generate_demo_packets
from firewall.threat_detector import ThreatConfig, ThreatDetector
from tests.helpers import BASE_TIME, make_packet

SAMPLE_RULES = Path(__file__).resolve().parents[1] / "config" / "rules.json"


class PacketFilterTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.tmp = Path(self._tmp.name)
        self.log_path = self.tmp / "firewall.log"
        self.logger = FirewallLogger(self.log_path)
        self.addCleanup(self.logger.close)
        self.rules = RuleSet.load(SAMPLE_RULES)

    def log_lines(self):
        return self.log_path.read_text(encoding="utf-8").splitlines()

    def test_decisions_are_returned_logged_and_counted(self):
        pf = PacketFilter(self.rules, self.logger)
        blocked = pf.process(make_packet(dst_port=23))
        allowed = pf.process(make_packet(dst_port=443))
        self.assertTrue(blocked.decision.is_blocked)
        self.assertFalse(allowed.decision.is_blocked)
        self.assertEqual((pf.stats.total, pf.stats.blocked, pf.stats.allowed), (2, 1, 1))
        lines = self.log_lines()
        self.assertIn("BLOCKED", lines[0])
        self.assertIn("rule=#2", lines[0])
        self.assertIn("ALLOWED", lines[1])

    def test_log_allowed_false_logs_only_blocked(self):
        pf = PacketFilter(self.rules, self.logger, log_allowed=False)
        pf.process(make_packet(dst_port=443))
        pf.process(make_packet(dst_port=23))
        lines = self.log_lines()
        self.assertEqual(len(lines), 1)
        self.assertIn("BLOCKED", lines[0])
        self.assertEqual(pf.stats.allowed, 1)  # still counted

    def test_threat_alert_is_attached_and_logged(self):
        detector = ThreatDetector(ThreatConfig(blocked_attempt_threshold=3))
        pf = PacketFilter(self.rules, self.logger, detector)
        results = [pf.process(make_packet(src_ip="10.0.0.9", dst_port=23,
                                          timestamp=BASE_TIME + i)) for i in range(3)]
        self.assertEqual([len(r.alerts) for r in results], [0, 0, 1])
        self.assertEqual(pf.stats.alerts, 1)
        self.assertTrue(any("WARNING" in l and "BLOCKED_TRAFFIC" in l for l in self.log_lines()))

    def test_demo_traffic_end_to_end(self):
        detector = ThreatDetector(ThreatConfig())
        pf = PacketFilter(self.rules, self.logger, detector)
        alerts = [a.kind for p in generate_demo_packets(BASE_TIME)
                  for a in pf.process(p).alerts]
        self.assertEqual(sorted(alerts), ["BLOCKED_TRAFFIC", "PORT_SCAN", "REPEATED_CONNECTIONS"])

    def test_rules_hot_reload_and_bad_file_keeps_old_rules(self):
        path = self.tmp / "rules.json"
        path.write_text(json.dumps({"default_policy": "ALLOW", "rules": []}))
        live = RuleSet.load(path)
        pf = PacketFilter(live, self.logger, reload_interval=0)
        self.assertFalse(pf.process(make_packet(dst_port=8080)).decision.is_blocked)

        def rewrite(text, bump):
            path.write_text(text)
            st = path.stat()
            os.utime(path, ns=(st.st_atime_ns, st.st_mtime_ns + bump))

        rewrite(json.dumps({"rules": [{"action": "BLOCK", "dst_port": 8080}]}), 10_000_000)
        self.assertTrue(pf.process(make_packet(dst_port=8080)).decision.is_blocked)

        rewrite("{ broken json", 20_000_000)  # admin typo: old rules must stay active
        self.assertTrue(pf.process(make_packet(dst_port=8080)).decision.is_blocked)
        self.assertTrue(any("keeping previous rules" in l for l in self.log_lines()))


class IptablesExportTests(unittest.TestCase):
    def test_sample_rules_translate(self):
        script = generate_script(RuleSet.load(SAMPLE_RULES))
        self.assertIn("iptables -A PYFW -s 192.168.1.100", script)
        self.assertIn("-p tcp --dport 23", script)
        self.assertIn("-p udp --dport 53", script)
        self.assertIn("-j ACCEPT", script)
        self.assertIn("# iptables  -I INPUT -j PYFW", script)  # activation stays commented out

    def test_nothing_is_active_by_default(self):
        script = generate_script(RuleSet())
        active = [l for l in script.splitlines() if l and not l.startswith("#")]
        self.assertFalse(any("-I INPUT" in l for l in active))

    def test_ranges_default_block_and_disabled_rules(self):
        rs = RuleSet(default_policy="BLOCK")
        rs.add(action="ALLOW", dst_port="8000-8100")
        rs.add(action="BLOCK", dst_port=22, enabled=False)
        rs.add(action="ALLOW", protocol="ICMP")
        script = generate_script(rs)
        self.assertIn("-p tcp --dport 8000:8100", script)
        self.assertIn("-p udp --dport 8000:8100", script)   # ANY + port => tcp and udp
        self.assertNotIn("--dport 22", script)              # disabled
        self.assertIn("-p ipv6-icmp", script)
        self.assertIn("iptables  -A PYFW -j DROP", script)  # default policy BLOCK

    def test_ip_family_selection(self):
        rs = RuleSet()
        rs.add(action="BLOCK", src_ip="2001:db8::/32")
        rs.add(action="BLOCK", src_ip="10.0.0.0/8")
        rs.add(action="BLOCK", src_ip="10.0.0.1", dst_ip="2001:db8::1")
        script = generate_script(rs)
        self.assertIn("ip6tables -A PYFW -s 2001:db8::/32", script)
        self.assertNotIn("iptables -A PYFW -s 2001", script)
        self.assertIn("rule #3 skipped", script)


if __name__ == "__main__":
    unittest.main()
