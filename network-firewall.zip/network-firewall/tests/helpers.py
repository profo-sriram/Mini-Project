"""Shared helpers for the test-suite."""

from __future__ import annotations

from firewall.models import PacketInfo

BASE_TIME = 1_700_000_000.0


def make_packet(
    src_ip: str = "10.0.0.2",
    dst_ip: str = "10.0.0.5",
    protocol: str = "TCP",
    src_port: int | None = 50000,
    dst_port: int | None = 80,
    size: int = 60,
    timestamp: float = BASE_TIME,
    flags: str = "",
) -> PacketInfo:
    """Build a PacketInfo with sensible defaults (ICMP automatically has no ports)."""
    if protocol == "ICMP":
        src_port = dst_port = None
    return PacketInfo(src_ip, dst_ip, protocol, size, src_port, dst_port, timestamp, flags)
