"""Tests for the sliding-window threat detector."""

import unittest

from firewall.threat_detector import (
    BLOCKED_TRAFFIC, EXCESSIVE_TRAFFIC, PORT_SCAN, REPEATED_CONNECTIONS,
    ThreatConfig, ThreatConfigError, ThreatDetector,
)
from tests.helpers import BASE_TIME, make_packet

CFG = ThreatConfig(window_seconds=10, port_scan_threshold=5, repeated_attempt_threshold=4,
                   blocked_attempt_threshold=3, packet_rate_threshold=20,
                   alert_cooldown_seconds=30)


def kinds(alerts):
    return [a.kind for a in alerts]


class ThreatDetectorTests(unittest.TestCase):
    def setUp(self):
        self.detector = ThreatDetector(CFG)

    def feed(self, packets, blocked=False):
        out = []
        for pkt in packets:
            out += self.detector.observe(pkt, blocked)
        return out

    def test_port_scan_detected(self):
        pkts = [make_packet(src_ip="10.0.0.66", dst_port=p, flags="S", timestamp=BASE_TIME + i * 0.1)
                for i, p in enumerate(range(20, 26))]
        alerts = self.feed(pkts)
        self.assertEqual(kinds(alerts), [PORT_SCAN])
        self.assertEqual(alerts[0].src_ip, "10.0.0.66")
        self.assertIn("5 distinct", alerts[0].message)

    def test_repeated_connection_attempts_detected(self):
        pkts = [make_packet(dst_port=22, src_port=40000 + i, flags="S", timestamp=BASE_TIME + i)
                for i in range(4)]
        self.assertEqual(kinds(self.feed(pkts)), [REPEATED_CONNECTIONS])

    def test_established_traffic_is_not_counted_as_connection_attempts(self):
        pkts = [make_packet(dst_port=22, flags="PA", timestamp=BASE_TIME + i) for i in range(10)]
        self.assertEqual(self.feed(pkts), [])

    def test_blocked_port_access_detected(self):
        pkts = [make_packet(dst_port=23, timestamp=BASE_TIME + i) for i in range(3)]
        alerts = self.feed(pkts, blocked=True)
        self.assertEqual(kinds(alerts), [BLOCKED_TRAFFIC])

    def test_excessive_packets_detected(self):
        pkts = [make_packet(dst_port=80, flags="PA", timestamp=BASE_TIME + i * 0.1) for i in range(20)]
        self.assertEqual(kinds(self.feed(pkts)), [EXCESSIVE_TRAFFIC])

    def test_normal_traffic_raises_nothing(self):
        pkts = [make_packet(dst_port=p, flags="PA", timestamp=BASE_TIME + i * 5)
                for i, p in enumerate([80, 443, 80, 443, 80, 443, 80, 443])]
        self.assertEqual(self.feed(pkts), [])

    def test_activity_outside_window_is_forgotten(self):
        slow = [make_packet(dst_port=p, flags="S", timestamp=BASE_TIME + i * 6)
                for i, p in enumerate(range(20, 30))]  # 1 port every 6 s, window is 10 s
        self.assertEqual(self.feed(slow), [])

    def test_sources_are_tracked_independently(self):
        pkts = [make_packet(src_ip=f"10.0.0.{i}", dst_port=23, timestamp=BASE_TIME + i)
                for i in range(1, 9)]
        self.assertEqual(self.feed(pkts, blocked=True), [])

    def test_cooldown_suppresses_duplicates_then_rearms(self):
        def scan(start, offset):
            return [make_packet(dst_port=p, flags="S", timestamp=start + i * 0.1)
                    for i, p in enumerate(range(offset, offset + 8))]
        self.assertEqual(kinds(self.feed(scan(BASE_TIME, 100))), [PORT_SCAN])      # alert once
        self.assertEqual(self.feed(scan(BASE_TIME + 1, 200)), [])                  # in cooldown
        self.assertEqual(kinds(self.feed(scan(BASE_TIME + 100, 300))), [PORT_SCAN])  # re-armed

    def test_disabled_detector_returns_nothing(self):
        detector = ThreatDetector(ThreatConfig(enabled=False))
        pkts = [make_packet(dst_port=p, flags="S") for p in range(1, 100)]
        self.assertEqual([a for p in pkts for a in detector.observe(p, True)], [])

    def test_memory_is_bounded(self):
        detector = ThreatDetector(ThreatConfig(max_tracked_sources=50))
        for i in range(500):
            detector.observe(make_packet(src_ip=f"10.1.{i // 250}.{i % 250}",
                                         timestamp=BASE_TIME + i * 0.001), False)
        self.assertLessEqual(detector.tracked_sources, 55)

    def test_idle_sources_are_cleaned_up(self):
        detector = ThreatDetector(CFG)
        for i in range(999):
            detector.observe(make_packet(src_ip=f"10.2.{i // 250}.{i % 250}", timestamp=BASE_TIME), False)
        detector.observe(make_packet(src_ip="10.9.9.9", timestamp=BASE_TIME + 500), False)  # 1000th
        self.assertEqual(detector.tracked_sources, 1)


class ThreatConfigTests(unittest.TestCase):
    def test_invalid_configs_rejected(self):
        for bad in ({"port_scan_threshold": 0}, {"window_seconds": -1}, {"enabled": "yes"},
                    {"packet_rate_threshold": "many"}, {"unknown_key": 1}):
            with self.subTest(bad=bad), self.assertRaises(ThreatConfigError):
                ThreatConfig.from_dict(bad)

    def test_partial_config_uses_defaults(self):
        cfg = ThreatConfig.from_dict({"port_scan_threshold": 99})
        self.assertEqual(cfg.port_scan_threshold, 99)
        self.assertEqual(cfg.window_seconds, 10)


if __name__ == "__main__":
    unittest.main()
