"""Tests for the structured log file."""

import logging
import tempfile
import unittest
from pathlib import Path

from firewall.logger import FirewallLogger, follow_log, format_alert, tail_log
from firewall.rule_engine import RuleSet
from firewall.threat_detector import PORT_SCAN, ThreatAlert
from tests.helpers import BASE_TIME, make_packet


class LoggerTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.path = Path(self._tmp.name) / "logs" / "firewall.log"  # parent dir is auto-created
        self.logger = FirewallLogger(self.path)
        self.addCleanup(self.logger.close)

    def lines(self):
        return self.path.read_text(encoding="utf-8").splitlines()

    def test_blocked_decision_contains_all_required_fields(self):
        rs = RuleSet()
        rs.add(action="BLOCK", protocol="TCP", dst_port=23)
        packet = make_packet(src_ip="192.0.2.7", dst_ip="10.0.0.5", src_port=51234, dst_port=23,
                             size=60, timestamp=BASE_TIME)
        self.logger.log_decision(packet, rs.evaluate(packet))

        (line,) = self.lines()
        self.assertRegex(line, r"^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d \| INFO ")
        for fragment in ("BLOCKED", "proto=TCP", "src_ip=192.0.2.7", "src_port=51234",
                         "dst_ip=10.0.0.5", "dst_port=23", "size=60", "rule=#1",
                         "reason=Blocked by rule #1"):
            self.assertIn(fragment, line)

    def test_allowed_decision_and_default_policy_marker(self):
        packet = make_packet(protocol="ICMP")
        self.logger.log_decision(packet, RuleSet().evaluate(packet))
        (line,) = self.lines()
        self.assertIn("ALLOWED", line)
        self.assertIn("src_port=-", line)  # ICMP has no ports
        self.assertIn("rule=default-policy", line)

    def test_alert_is_logged_as_warning(self):
        alert = ThreatAlert(BASE_TIME, PORT_SCAN, "10.0.0.66", "possible port scan: 15 ports")
        self.logger.log_alert(alert)
        (line,) = self.lines()
        self.assertIn("WARNING", line)
        self.assertIn("THREAT", line)
        self.assertEqual(line, format_alert(alert))
        self.assertIn("type=PORT_SCAN", line)
        self.assertIn("src_ip=10.0.0.66", line)

    def test_system_event_and_levels(self):
        self.logger.log_event("Firewall started")
        self.logger.log_event("Capture failed", logging.ERROR)
        first, second = self.lines()
        self.assertIn("INFO", first)
        self.assertRegex(second, r"ERROR\s+\| SYSTEM")

    def test_lines_are_written_immediately(self):
        self.logger.log_event("one")
        self.assertEqual(len(self.lines()), 1)  # no explicit flush/close needed
        self.logger.log_event("two")
        self.assertEqual(len(self.lines()), 2)

    def test_new_logger_for_same_file_does_not_duplicate_lines(self):
        second = FirewallLogger(self.path)
        self.addCleanup(second.close)
        second.log_event("hello")
        self.assertEqual(len(self.lines()), 1)

    def test_tail_and_filter(self):
        rs = RuleSet(default_policy="ALLOW")
        rs.add(action="BLOCK", dst_port=23)
        for port in (80, 23, 443, 23):
            pkt = make_packet(dst_port=port)
            self.logger.log_decision(pkt, rs.evaluate(pkt))
        self.assertEqual(len(tail_log(self.path, 2)), 2)
        self.assertEqual(len(tail_log(self.path, 10, "| BLOCKED")), 2)
        self.assertTrue(all("dst_port=23" in l for l in tail_log(self.path, 10, "| BLOCKED")))
        self.assertEqual(tail_log(self.path.with_name("missing.log")), [])

    def test_rotation(self):
        rotating = FirewallLogger(Path(self._tmp.name) / "rot.log", max_bytes=300, backup_count=2)
        self.addCleanup(rotating.close)
        for i in range(20):
            rotating.log_event(f"event number {i} " + "x" * 40)
        self.assertTrue((Path(self._tmp.name) / "rot.log.1").exists())

    def test_follow_yields_new_lines_only(self):
        self.logger.log_event("old line")
        stream = follow_log(self.path, poll_seconds=0.01)
        import threading
        threading.Timer(0.1, lambda: self.logger.log_event("new line")).start()
        self.assertIn("new line", next(stream))


if __name__ == "__main__":
    unittest.main()
